<?php

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;

if ($params->get('articles_layout') == 1) {
    $gridCols = 'fr-grid-row';
    $columnClass = 'fr-col-12 fr-col-lg-' . (12 / (int) $params->get('layout_columns', 3));
} else {
    $gridCols = '';
    $columnClass = 'fr-col-12';
}
?>

<div class="mod-articles-items <?php echo $gridCols; ?>">
    <?php foreach ($items as $item) : ?>
        <?php
            $hasImage = in_array($params->get('img_intro_full'), ['intro', 'full']) && !empty($item->imageSrc);
            $link = htmlspecialchars($item->link, ENT_QUOTES, 'UTF-8');
        ?>
        <div class="blog-item fr-col <?php echo $columnClass; ?>">
          <!-- Début de la card -->
            <div class="fr-card fr-enlarge-link">
                <div class="fr-card__body">
                    <div class="item-content fr-card__content">
                        <?php if ($params->get('item_title')) : ?>
                            <div class="item-title fr-card__title"><!-- Si titre d'article affiché et lien sur titre -->
                                <<?php echo $params->get('item_heading', 'h3'); ?>>
                                    <?php if ($params->get('link_titles') == 1) : ?>
                                        <a href="<?php echo $link; ?>" class="mod-articles-link <?php echo $item->active; ?>" itemprop="url">
                                            <?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>
                                        </a>
                                <?php else : ?>
                                    <?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>
                                <?php endif; ?>
                                </<?php echo $params->get('item_heading', 'h3'); ?>>
                            </div>
                        <?php else : ?><!-- Si titre d'article PAS affiché donc pas de lien sur titre mais on conserve le lien sur la card -->
                            <div class="item-title fr-card__title">
                                <<?php echo $params->get('item_heading', 'h3'); ?>>
                                        <a href="<?php echo $link; ?>" class="mod-articles-link <?php echo $item->active; ?>" itemprop="url">
                                       </a>
                                </<?php echo $params->get('item_heading', 'h3'); ?>>
                            </div>
                        <?php endif; ?>

                        <?php echo $item->event->afterDisplayTitle; ?>

                        <div class="fr-card__desc">
                            <?php echo $item->event->beforeDisplayContent; ?>
                            <?php if ($params->get('show_introtext', 1)) : ?>
                                <?php echo $item->introtext; ?>
                            <?php endif; ?>
                            <?php echo $item->event->afterDisplayContent; ?>
                        </div>

                        <?php if ($params->get('show_readmore')) : ?>
                            <?php if ($params->get('show_readmore_title', '') !== '') : ?>
                                <?php
                                    $item->params->set('show_readmore_title', $params->get('show_readmore_title'));
                                    $item->params->set('readmore_limit', $params->get('readmore_limit'));
                                ?>
                            <?php endif; ?>
                            <p class="fr-card__footer">
                                <?php echo LayoutHelper::render('joomla.content.readmore', ['item' => $item, 'params' => $item->params, 'link' => $item->link]); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if ($hasImage) : ?>
                    <div class="fr-card__header">
                        <div class="fr-card__img">
							<div class="card-image-wrapper">
								<?php echo LayoutHelper::render('joomla.content.' . $params->get('img_intro_full') . '_image', $item); ?>
							</div>
                        </div>

                        <?php if ($params->get('show_tags', 0) && $item->tags->itemTags) : ?>
                            <?php echo LayoutHelper::render('joomla.content.tags', $item->tags->itemTags); ?>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
          <!-- Fin de la card -->
    <?php endforeach; ?>
</div>
