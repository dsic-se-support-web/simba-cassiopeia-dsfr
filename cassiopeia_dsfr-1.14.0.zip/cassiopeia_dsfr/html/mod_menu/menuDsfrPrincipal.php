<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_menu
 *
 * @copyright   (C) 2009 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $app->getDocument()->getWebAssetManager();
$wa->registerAndUseScript('mod_menu', 'mod_menu/menu.min.js', [], ['type' => 'module']);

$id = '';

if ($tagId = $params->get('tag_id', '')) {
    $id = ' id="' . $tagId . '"';
}
// foreach ($list as $i => &$item) {
// print_r($item->title);
// echo(" / ");
// }
// The menu class is deprecated. Use mod-menu instead
?>

<nav class="fr-nav " id="menu" role="navigation" aria-label="Menu principal" aria-labelledby="button-578">

    <ul <?php echo $id; ?> class="<?php echo $class_sfx; ?> fr-nav__list">
     
        <?php foreach ($list as $i => &$item) {

            $itemParams = $item->getParams();
            $class      = 'nav-item item-' . $item->id;

            if ($item->id == $default_id) {
                $class .= ' default';
            }

            if ($item->id == $active_id || ($item->type === 'alias' && $itemParams->get('aliasoptions') == $active_id)) {
                $class .= ' current';
            }

		/* Debut - Recherche de la classe de lien de menu pour mise en avant d'un menu de type séparateur */
			// Récupérer la classe CSS personnalisée attribuée au lien du menu
			$cssClass = $itemParams->get('link_css_class', '');  // Si aucune classe n'est définie, on prend une chaîne vide

			// Récupérer les paramètres de l'élément de menu
			$itemParams = $item->getParams();

			// Vérifier si le paramètre 'link_css_class' est disponible
			if ($itemParams && $itemParams->exists('menu-anchor_css'))
			{
				$cssClass = $itemParams->get('menu-anchor_css', '');
                $itemParams->set('custom_button_class', $cssClass); // Transmet la classe pour default_separator.php
			}
			else
			{
				$cssClass = ''; // Aucune classe personnalisée
			}
		/* Fin - Recherche de la classe de lien de menu pour mise en avant d'un menu de type séparateur */

            //pour ajouter la classe active
            if (in_array($item->id, $path)) {
                $class .= ' active';
            } elseif ($item->type === 'alias') {
                $aliasToId = $itemParams->get('aliasoptions');

                if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
                    $class .= ' active';
                } elseif (in_array($aliasToId, $path)) {
                    $class .= ' alias-parent-active';
                }
            }

            if ($item->type === 'separator') {
                $class .= ' divider';
            }

            if ($item->deeper) {
                $class .= ' deeper';
            }

            if ($item->parent) {
                $class .= ' parent';
            }

            //Verification si on est bien au dernier élément du menu pour pouvoir mettre la class pour le boutton mis en avant (contact, bouton annuaire etc...)
            $isLastChild = 0;
            if ($item === end($list)) {
                $isLastChild = 1;
            }

            echo '<li class="' . $class . ' fr-nav__item ' . ($isLastChild ? 'lastChild' : '') . '">';

            switch ($item->type):
                case 'separator':
              
                    //j'ai repris le code qui ajoute la classe 'active' juste en haut et j'ai remplacer l'ajout de la class active par le bouton qui a l'attribut aria-current="true"
					// Ajout de $cssClass pour les liens de menu séparateurs qui ont une classe de lien de menu pour mise en avant
                    if (in_array($item->id, $path)) {
                        echo '<button class="fr-nav__btn ' . $cssClass . '" aria-expanded="false" aria-controls="menu-' . $item->id . '" aria-current="true" > ';
                    } elseif ($item->type === 'alias') {
                        $aliasToId = $itemParams->get('aliasoptions');

                        if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
                            echo '<button class="fr-nav__btn ' . $cssClass . '" aria-expanded="false" aria-controls="menu-' . $item->id . '" aria-current="true" > ';
                        } elseif (in_array($aliasToId, $path)) {
                            echo '<button class="fr-nav__btn ' . $cssClass . '" aria-expanded="false" aria-controls="menu-' . $item->id . '" aria-current="true" > ';
                        }
                    } else {
                        echo '<button class="fr-nav__btn ' . $cssClass . '" aria-expanded="false" aria-controls="menu-' . $item->id . '"  > ';
                    }

                    require ModuleHelper::getLayoutPath('mod_menu', 'default_' . $item->type);
                    echo ' </button>';
                    break;
                case 'alias':
                    require ModuleHelper::getLayoutPath('mod_menu/principal', 'default_componentDsfr');
                    break;
                case 'component':
                    require ModuleHelper::getLayoutPath('mod_menu/principal', 'default_componentDsfr');
                    break;
                case 'heading':
                case 'url':
                    require ModuleHelper::getLayoutPath('mod_menu/principal', 'default_urlDsfr');
                    break;

                default:
                    require ModuleHelper::getLayoutPath('mod_menu', 'default_url');
                    break;
            endswitch;

            // The next item is deeper.
            if ($item->deeper) {

                echo '<div class="fr-collapse fr-menu" id="menu-' . $item->id . '">';
                echo '<ul class="fr-menu__list mod-menu__sub list-unstyled small ">';
            } elseif ($item->shallower) {
                // The next item is shallower.

                echo '</li>';
                echo str_repeat('</ul></div></li>', $item->level_diff);
            } else {
                // The next item is on the same level.
                echo '</li>';
            }
        }
        ?></ul>
</nav>
