<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_menu
 *
 * @copyright   (C) 2009 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $app->getDocument()->getWebAssetManager();
$wa->registerAndUseScript('mod_menu', 'mod_menu/menu.min.js', [], ['type' => 'module']);

$id = '';

if ($tagId = $params->get('tag_id', '')) {
    $id = ' id="' . $tagId . '"';
}
// foreach ($list as $i => &$item) {
// print_r($item->title);
// echo(" / ");
// }
// The menu class is deprecated. Use mod-menu instead

?>

<nav class="fr-sidemenu fr-sidemenu--sticky-full-height" role="navigation" aria-labelledby="fr-sidemenu-title">
    <div class="fr-sidemenu__inner">
        <button
            class="fr-sidemenu__btn"
            aria-controls="fr-sidemenu-wrapper"
            aria-expanded="false">
            Dans cette rubrique
        </button>
        <div class="fr-collapse" id="fr-sidemenu-wrapper">
            <!-- <div class="fr-sidemenu__title" id="fr-sidemenu-title"><?php //echo $module->title 
                                                                        ?></div> Le titre est affiché via joomla-->


            <ul class="fr-sidemenu__list">
                <?php foreach ($list as $i => &$item) {
                    $itemParams = $item->getParams();
                    $class      = 'fr-ml-1w fr-mt-1v nav-item item-' . $item->id;

                    if ($item->id == $default_id) {
                        $class .= ' default';
                    }

                    if ($item->id == $active_id || ($item->type === 'alias' && $itemParams->get('aliasoptions') == $active_id)) {
                        $class .= ' current';
                    }

                    //pour ajouter la classe active
                    if (in_array($item->id, $path)) {
                        $class .= ' active';
                    } elseif ($item->type === 'alias') {
                        $aliasToId = $itemParams->get('aliasoptions');

                        if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
                            $class .= ' active';
                        } elseif (in_array($aliasToId, $path)) {
                            $class .= ' alias-parent-active';
                        }
                    }

                    if ($item->type === 'separator') {
                        $class .= ' divider';
                    }

                    if ($item->deeper) {
                        $class .= ' deeper';
                    }

                    if ($item->parent) {
                        $class .= ' parent';
                    }

                    echo '<li class="' . $class . ' fr-sidemenu__item">';

                    switch ($item->type):
                        case 'separator':

                            //j'ai repris le code qui ajoute la classe 'active' juste en haut et j'ai remplacer l'ajout de la class active par le bouton qui a l'attribut aria-current="true"
                            if (in_array($item->id, $path)) {
                                echo '<button class="fr-sidemenu__btn" aria-expanded="true" aria-controls="fr-sidemenu-item-' . $item->id . '" aria-current="true" > ';
                            } elseif ($item->type === 'alias') {
                                $aliasToId = $itemParams->get('aliasoptions');

                                if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
                                    echo '<button class="fr-sidemenu__btn" aria-expanded="true" aria-controls="fr-sidemenu-item-' . $item->id . '" aria-current="true" > ';
                                } elseif (in_array($aliasToId, $path)) {
                                    echo '<button class="fr-sidemenu__btn" aria-expanded="true" aria-controls="fr-sidemenu-item-' . $item->id . '" aria-current="true" > ';
                                }
                            } else {
                                echo '<button class="fr-sidemenu__btn" aria-expanded="false" aria-controls="fr-sidemenu-item-' . $item->id . '"  > ';
                            }

                            require ModuleHelper::getLayoutPath('mod_menu', 'default_' . $item->type);
                            echo ' </button>';
                            break;
                        case 'component':
                            require ModuleHelper::getLayoutPath('mod_menu/lateral', 'default_componentDsfrLateral');
                            break;
                        case 'heading':
                        case 'url':
                            require ModuleHelper::getLayoutPath('mod_menu/lateral', 'default_urlDsfrLateral');
                            break;

                        default:
                            require ModuleHelper::getLayoutPath('mod_menu', 'default_url');
                            break;
                    endswitch;

                    // The next item is deeper.
                    if ($item->deeper) {

                        if (in_array($item->id, $path)) {
                            echo '<div class="fr-collapse fr-collapse--expanded" id="fr-sidemenu-item-' . $item->id . '">';
                        } elseif ($item->type === 'alias') {
                            $aliasToId = $itemParams->get('aliasoptions');

                            if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
                                echo '<div class="fr-collapse fr-collapse--expanded" id="fr-sidemenu-item-' . $item->id . '">';
                            } elseif (in_array($aliasToId, $path)) {
                                echo '<div class="fr-collapse fr-collapse--expanded" id="fr-sidemenu-item-' . $item->id . '">';
                            }
                        } else {
                            echo '<div class="fr-collapse" id="fr-sidemenu-item-' . $item->id . '">';
                        }


                        echo '<ul class="mod-menu__sub list-unstyled small fr-sidemenu__list">';
                    } elseif ($item->shallower) {
                        // The next item is shallower.

                        echo '</li>';
                        echo str_repeat('</ul></div></li>', $item->level_diff);
                    } else {
                        // The next item is on the same level.
                        echo '</li>';
                    }
                }
                ?>
            </ul>
        </div>
    </div>
</nav>