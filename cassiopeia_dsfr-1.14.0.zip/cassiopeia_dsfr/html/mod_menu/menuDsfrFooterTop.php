<?php
defined('_JEXEC') or die;

// Taille Bootstrap (paramètre du module)
$bootstrapSize = (int) $params->get('bootstrap_size', 2);

// Intégration du DSFR
$colClass = 'fr-col-' . ($bootstrapSize > 0 && $bootstrapSize <= 12 ? $bootstrapSize : 2);
?>
<div class="fr-col-12 fr-col-sm-3 <?php echo $colClass ?>">
  <?php if ($module->showtitle) : ?>
    <h3 class="fr-footer__top-cat"><?php echo htmlspecialchars($module->title, ENT_QUOTES, 'UTF-8'); ?></h3>
  <?php endif; ?>
  <ul class="fr-footer__top-list">
    <?php foreach ($list as $item) : ?>
      <li><a href="<?php echo $item->flink; ?>" class="fr-footer__top-link"><?php echo $item->title; ?></a></li>
    <?php endforeach; ?>
  </ul>
</div>