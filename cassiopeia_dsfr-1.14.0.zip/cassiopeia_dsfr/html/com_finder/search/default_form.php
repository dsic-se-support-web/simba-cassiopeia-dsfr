<?php
defined('_JEXEC') or die;


use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;

$this->document->getWebAssetManager()
    ->useStyle('com_finder.finder')
    ->useScript('com_finder.finder');

$app = Factory::getApplication();
$input = $app->input;

// Valeurs existantes - CORRECTION ICI
$currentQuery = $input->get('q', '', 'string');
$currentOrder = $input->get('o', 'relevance', 'string');
$currentPeriod = $input->get('created_options', '', 'string');

// Récupération des dates personnalisées
$createdArray = $input->get('created', [], 'array');
$createdMin = isset($createdArray['min']) ? $createdArray['min'] : '';
$createdMax = isset($createdArray['max']) ? $createdArray['max'] : '';

/*
* This segment of code sets up the autocompleter.
*/

if ($this->params->get('show_autosuggest', 1)) {
    $this->document->getWebAssetManager()->usePreset('awesomplete');
    $this->document->addScriptOptions('finder-search', ['url' => Route::_('index.php?option=com_finder&task=suggestions.suggest&format=json&tmpl=component', false)]);

    Text::script('JLIB_JS_AJAX_ERROR_OTHER');
    Text::script('JLIB_JS_AJAX_ERROR_PARSE');
}

?>

<div class="com-finder finder">

    <?php if ($this->params->get('show_page_heading')) : ?>
        <h1>
            <?= $this->escape($this->params->get('page_heading') ?: $this->params->get('page_title')); ?>
        </h1>
    <?php endif; ?>

    <form action="<?= Route::_('index.php?option=com_finder&view=search'); ?>" method="GET" class="js-finder-searchform" id="finder-form">
        <input type="hidden" name="option" value="com_finder">
        <input type="hidden" name="view" value="search">

        <!-- Recherche -->
		<fieldset class="fr-fieldset fr-mb-0" role="group">
			<legend class="fr-sr-only">Filtrer</legend>
			<div class="fr-mb-4w">
				<h2 class="fr-h4 fr-mb-2w">Filtrer</h2>
					<div class="fr-search-bar" id="search-sidebar">
                        <label class="fr-label visually-hidden" for="q-sidebar">Rechercher</label> <!-- Label pour RGAA -->
						<input class="fr-input" type="search" id="q-sidebar" name="q" placeholder="Rechercher..." value="<?= $this->escape($currentQuery); ?>" />
						<button class="fr-btn fr-btn--fluid" type="submit" title="Rechercher">Rechercher</button>
					</div>
			</div>
		</fieldset>

        <!-- Organiser -->
		<fieldset class="fr-fieldset fr-mb-0" role="group">
			<legend class="fr-sr-only">Organiser</legend>
			<div class="fr-mb-4w">
				<h3 class="fr-h6 fr-mb-2w">Organiser</h3>
					<div class="fr-select-group">
						<label class="fr-label visually-hidden" for="sort-order">Organiser par</label>
						<select class="fr-select" id="sort-order" name="o"> 
							<option value="relevance" <?= $currentOrder == 'relevance' ? 'selected' : ''; ?>>Le plus pertinent en premier</option>
							<option value="date_desc" <?= $currentOrder == 'date_desc' ? 'selected' : ''; ?>>Le plus récent en premier</option>
						</select>
					</div>
			</div>
		</fieldset>

        <!-- Période prédéfinie / personnalisée -->
        <div class="fr-accordions-group" data-fr-js-accordions-group="true">

            <!-- Périodes prédéfinies -->
            <section class="fr-accordion" data-fr-js-accordion="true">
                <h3 class="fr-accordion__title">
                    <button type="button" class="fr-accordion__btn" aria-expanded="true" aria-controls="accordion-pred" data-fr-js-collapse-button="true">
                        Période prédéfinie
                    </button>
                </h3>
                <div id="accordion-pred" class="fr-collapse fr-collapse--expanded" data-fr-js-collapse="true">
                    <fieldset class="fr-fieldset fr-mb-0" role="group">
                        <legend class="fr-sr-only">Choisir une période prédéfinie</legend>
                        <?php
                        $periods = [
                            'last7days' => "Moins d'une semaine",
                            'lastMonth' => "Moins d'un mois",
                            'lastYear' => "Moins d'un an"
                        ];
                        foreach($periods as $val=>$label): ?>
                        <div class="fr-formElement fr-col-12 fr-mt-3v">
                            <div class="fr-input-group fr-radio-group">
                                <input type="radio" id="created_<?= $val; ?>" 
                                       name="created_options" 
                                       value="<?= $val; ?>" 
                                       class="form-radio fr-input"
                                       <?= ($currentPeriod === $val) ? 'checked' : ''; ?>>
                                <label for="created_<?= $val; ?>" class="option fr-label"><?= $label; ?></label>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </fieldset>
                </div>
            </section>

            <!-- Période personnalisée -->
            <section class="fr-accordion" data-fr-js-accordion="true">
                <h3 class="fr-accordion__title">
                    <button type="button" class="fr-accordion__btn" aria-expanded="false" aria-controls="accordion-custom" data-fr-js-collapse-button="true">
                        Période personnalisée
                    </button>
                </h3>
                <div id="accordion-custom" class="fr-collapse" data-fr-js-collapse="true">
                    <fieldset class="fr-fieldset fr-mb-0" role="group">
                        <legend class="fr-sr-only">Choisir une période personnalisée</legend>
                        <div class="fr-formElement fr-col-12 fr-mt-3v">
                            <label for="custom-start" class="fr-label">Date de début</label>
                            <input type="date" id="custom-start" class="fr-input" name="created[min]" value="<?= htmlspecialchars($createdMin); ?>">
                        </div>
                        <div class="fr-formElement fr-col-12 fr-mt-3v">
                            <label for="custom-end" class="fr-label">Date de fin</label>
                            <input type="date" id="custom-end" class="fr-input" name="created[max]" value="<?= htmlspecialchars($createdMax); ?>">
                        </div>
                    </fieldset>
                </div>
            </section>

        </div>

        <!-- Boutons -->
        <div class="fr-btns-group fr-mt-4w">
            <button type="submit" class="fr-btn fr-btn--fluid fr-btn--lg">Appliquer les filtres</button>
            <button type="button" class="fr-btn fr-btn--secondary fr-btn--fluid fr-btn--lg fr-mt-2w" id="reset-filters">Réinitialiser</button>
        </div>

    </form>
</div>

<!-- Début - Script pour autocomplétion -->
<?php if ($this->params->get('show_autosuggest', 1)) : ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const url = Joomla.getOptions('finder-search').url;

    // Il faut prendre en compte les 2 champs de recherche - 'q' pour le champ en entête et 'q-sidebar' pour le champ en latéral
    ['q', 'q-sidebar'].forEach(function(id) {
        const input = document.getElementById(id);
        if (!input) return;

        const awesomplete = new Awesomplete(input, {
            minChars: 2,
            maxItems: 10,
            autoFirst: false
        });

        input.addEventListener('input', function() {
            const value = this.value;

            if (value.length < 2) {
                awesomplete.list = [];
                return;
            }

            fetch(url + '&q=' + encodeURIComponent(value))
                .then(response => response.json())
                .then(data => {
                    awesomplete.list = data.suggestions || [];
                })
                .catch(() => {
                    awesomplete.list = [];
                });
        });
    });
});
</script>
<?php endif; ?>
<!-- Fin - Script pour autocomplétion -->

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('.js-finder-searchform');
    const customStart = document.getElementById('custom-start');
    const customEnd = document.getElementById('custom-end');
    const radios = document.querySelectorAll('input[name="created_options"]');
    const resetBtn = document.getElementById('reset-filters');

    // Fonction pour réinitialiser les filtres
    resetBtn.addEventListener('click', function() {
        window.location.href = '<?= Route::_('index.php?option=com_finder&view=search'); ?>';
    });

    // Calculer les dates pour période prédéfinie
    function applyPredefinedPeriod(value){
        const today = new Date();
        let startDate;
        switch(value){
            case 'last7days': 
                startDate = new Date(today.getFullYear(), today.getMonth(), today.getDate()-7); 
                break;
            case 'lastMonth': 
                startDate = new Date(today.getFullYear(), today.getMonth()-1, today.getDate()); 
                break;
            case 'lastYear': 
                startDate = new Date(today.getFullYear()-1, today.getMonth(), today.getDate()); 
                break;
            default: 
                return;
        }
        customStart.value = startDate.toISOString().split('T')[0];
        customEnd.value = today.toISOString().split('T')[0];
        
        // IMPORTANT : Soumettre automatiquement le formulaire après avoir défini les dates
        console.log('Dates calculées:', customStart.value, customEnd.value);
    }

    // Appliquer au chargement si radio cochée
    const checkedRadio = document.querySelector('input[name="created_options"]:checked');
    if(checkedRadio && checkedRadio.value) {
        applyPredefinedPeriod(checkedRadio.value);
    }

    // Écouter changements radios
    radios.forEach(r => r.addEventListener('change', function(){
        if(this.checked) {
            applyPredefinedPeriod(this.value);
        }
    }));

    // Si l'utilisateur change une date perso, décocher les radios
    [customStart, customEnd].forEach(input=>{
        input.addEventListener('change', ()=> {
            radios.forEach(r => r.checked = false);
        });
    });

    // Avant soumission, vérifier que les champs min/max sont bien définis
    form.addEventListener('submit', function(e){
        // Si radio période cochée mais min/max vide, recalculer
        const selected = document.querySelector('input[name="created_options"]:checked');
        if(selected && selected.value && (!customStart.value || !customEnd.value)){
            applyPredefinedPeriod(selected.value);
        }
        
        // Si aucune date n'est définie, ne pas envoyer les champs vides
        if(!customStart.value && !customEnd.value && !selected) {
            customStart.removeAttribute('name');
            customEnd.removeAttribute('name');
        }
    });
});
</script>
