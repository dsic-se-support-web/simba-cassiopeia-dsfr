<?php

/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Associations;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Content\Administrator\Extension\ContentComponent;
use Joomla\Component\Content\Site\Helper\RouteHelper;

/** @var \Joomla\Component\Content\Site\View\Article\HtmlView $this */
// Create shortcuts to some parameters.
$params  = $this->item->params;
$canEdit = $params->get('access-edit');
$user    = $this->getCurrentUser();
$info    = $params->get('info_block_position', 0);
$htag    = $this->params->get('show_page_heading') ? 'h2' : 'h1';

// Check if associations are implemented. If they are, define the parameter.
$assocParam        = (Associations::isEnabled() && $params->get('show_associations'));
$currentDate       = Factory::getDate()->format('Y-m-d H:i:s');
$isNotPublishedYet = $this->item->publish_up > $currentDate;
$isExpired         = !is_null($this->item->publish_down) && $this->item->publish_down < $currentDate;

// Fonction pour enrichir les tableaux standards au format DSFR
function enrichirTableDSFR($html) {
    if (empty($html)) {
        return $html;
    }
    
    libxml_use_internal_errors(true);
    
    // Créer un document DOM pour analyser tout le HTML
    $dom = new DOMDocument();
    $dom->loadHTML('<?xml encoding="utf-8" ?><div>' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    
    $xpath = new DOMXPath($dom);
    
    // Trouver tous les tableaux
    $tables = $xpath->query('//table');
    
 foreach ($tables as $table) {
    $shouldTransform = true;

	// Vérifier si le tableau a déjà des classes/attributs DSFR
    $tableClasses = $table->getAttribute('class') ?? '';
    $tableDataAttr = $table->getAttribute('data-fr-js-table-element') ?? '';
    // Attribut ou classe qui force l'exclusion du traitement DSFR
	// Dans le tableau à exclure du traitement, ajouter  class="no-dsfr" ou data-dsfr-skip="true" à la balise <table>
	// exemples : <table class="no-dsfr"> ou <table data-dsfr-skip="true">
    $skipAttr = strtolower($table->getAttribute('data-dsfr-skip')) ?? '';

    if (
        str_contains($tableClasses, 'fr-table') || 
        str_contains($tableClasses, 'no-dsfr') || 
        $skipAttr === 'true' || 
        $tableDataAttr === 'true'
    ) {
        $shouldTransform = false;
    }

    // Vérifier si le tableau est déjà dans une structure DSFR (tableau issu du tampon)
    if ($shouldTransform) {
        $ancestorQuery = $xpath->query('ancestor::*[contains(@class, "fr-table")]', $table);
        if ($ancestorQuery->length > 0) {
            $shouldTransform = false;
        }
    }


    // Nouvelle condition : ignorer si tableau avec une seule ligne contenant image + texte
    if ($shouldTransform) {
        $rows = $table->getElementsByTagName('tr');
        if ($rows->length === 1) {
            $row = $rows->item(0);
            $hasImage = false;
            $hasText  = false;

            foreach ($row->getElementsByTagName('td') as $cell) {
                if ($cell->getElementsByTagName('img')->length > 0) {
                    $hasImage = true;
                }
                if (trim($cell->textContent) !== '') {
                    $hasText = true;
                }
            }

            if ($hasImage && $hasText) {
                $shouldTransform = false;
            }
        }
    }




	// Si le tableau doit être transformé
    if ($shouldTransform) {
            // Générer un ID unique basé sur le contenu
            $tableContent = $dom->saveHTML($table);
            $uniqueId = 'table-' . substr(md5($tableContent . time()), 0, 8);
            
            // Supprimer les attributs indésirables
            $table->removeAttribute('border');
            $table->removeAttribute('style');
            
            // Définir l'ID unique
            $table->setAttribute('id', $uniqueId);
            
            // Ne pas ajouter de caption automatiquement
            // Le caption sera ajouté seulement s'il existe déjà dans le HTML source
            
            // Créer un thead à partir de la première ligne du tbody si nécessaire
            if ($table->getElementsByTagName('thead')->length === 0) {
                $tbodys = $table->getElementsByTagName('tbody');
                if ($tbodys->length > 0) {
                    $tbody = $tbodys->item(0);
                    $firstRow = $tbody->getElementsByTagName('tr')->item(0);
                    if ($firstRow) {
                        $thead = $dom->createElement('thead');
                        $theadRow = $dom->createElement('tr');
                        
                        foreach ($firstRow->getElementsByTagName('td') as $cell) {
                            $th = $dom->createElement('th', $cell->nodeValue);
                            $th->setAttribute('scope', 'col');
                            $theadRow->appendChild($th);
                        }
                        
                        $thead->appendChild($theadRow);
                        $table->insertBefore($thead, $tbody);
                        $tbody->removeChild($firstRow);
                    }
                }
            }
            
            // Ajouter des IDs aux lignes du tbody
            $tbody = $table->getElementsByTagName('tbody')->item(0);
            if ($tbody) {
                $rows = $tbody->getElementsByTagName('tr');
                foreach ($rows as $index => $row) {
                    $rowId = $uniqueId . '-row-key-' . ($index + 1);
                    $row->setAttribute('id', $rowId);
                    $row->setAttribute('data-row-key', ($index + 1));
                }
            }
            
            // Créer la structure DSFR
            $componentId = $uniqueId . '-component';
            $dsfrWrapper = $dom->createElement('div');
            $dsfrWrapper->setAttribute('id', $componentId);
            $dsfrWrapper->setAttribute('class', 'fr-table');
            
            $tableWrapper = $dom->createElement('div');
            $tableWrapper->setAttribute('class', 'fr-table__wrapper');
            
            $tableContainer = $dom->createElement('div');
            $tableContainer->setAttribute('class', 'fr-table__container');
            
            $tableContent = $dom->createElement('div');
            $tableContent->setAttribute('class', 'fr-table__content');
            
            // Construire la hiérarchie
            $tableContent->appendChild($table->cloneNode(true));
            $tableContainer->appendChild($tableContent);
            $tableWrapper->appendChild($tableContainer);
            $dsfrWrapper->appendChild($tableWrapper);
            
            // Remplacer le tableau original par la structure DSFR
            $table->parentNode->replaceChild($dsfrWrapper, $table);
        }
    }
    
    // Extraire le contenu de la div wrapper
    $body = $dom->getElementsByTagName('div')->item(0);
    $result = '';
    foreach ($body->childNodes as $child) {
        $result .= $dom->saveHTML($child);
    }
    
    return $result;
}
?>
<div class="com-content-article item-page<?php echo $this->pageclass_sfx; ?>">
    <meta itemprop="inLanguage" content="<?php echo ($this->item->language === '*') ? Factory::getApplication()->get('language') : $this->item->language; ?>">
    <?php if ($this->params->get('show_page_heading')) : ?>
    <div class="page-header">
        <h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
    </div>
    <?php endif;
    if (!empty($this->item->pagination) && !$this->item->paginationposition && $this->item->paginationrelative) {
        echo $this->item->pagination;
    }
    ?>

    <?php $useDefList = $params->get('show_modify_date') || $params->get('show_publish_date') || $params->get('show_create_date')
    || $params->get('show_hits') || $params->get('show_category') || $params->get('show_parent_category') || $params->get('show_author') || $assocParam; ?>

    <?php if ($params->get('show_title')) : ?>
    <div class="page-header">
        <<?php echo $htag; ?>>
            <?php echo $this->escape($this->item->title); ?>
        </<?php echo $htag; ?>>
        <?php if ($this->item->state == ContentComponent::CONDITION_UNPUBLISHED) : ?>
            <span class="badge bg-warning text-light"><?php echo Text::_('JUNPUBLISHED'); ?></span>
        <?php endif; ?>
        <?php if ($isNotPublishedYet) : ?>
            <span class="badge bg-warning text-light"><?php echo Text::_('JNOTPUBLISHEDYET'); ?></span>
        <?php endif; ?>
        <?php if ($isExpired) : ?>
            <span class="badge bg-warning text-light"><?php echo Text::_('JEXPIRED'); ?></span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ($canEdit) : ?>
        <?php echo LayoutHelper::render('joomla.content.icons', ['params' => $params, 'item' => $this->item]); ?>
    <?php endif; ?>

    <?php // Content is generated by content plugin event "onContentAfterTitle" ?>
    <?php echo $this->item->event->afterDisplayTitle; ?>

    <?php if ($useDefList && ($info == 0 || $info == 2)) : ?>
        <?php echo LayoutHelper::render('joomla.content.info_block', ['item' => $this->item, 'params' => $params, 'position' => 'above']); ?>
    <?php endif; ?>

    <?php if ($info == 0 && $params->get('show_tags', 1) && !empty($this->item->tags->itemTags)) : ?>
        <?php $this->item->tagLayout = new FileLayout('joomla.content.tags'); ?>

        <?php echo $this->item->tagLayout->render($this->item->tags->itemTags); ?>
    <?php endif; ?>

    <?php // Content is generated by content plugin event "onContentBeforeDisplay" ?>
    <?php echo $this->item->event->beforeDisplayContent; ?>

    <?php if ((int) $params->get('urls_position', 0) === 0) : ?>
        <?php echo $this->loadTemplate('links'); ?>
    <?php endif; ?>
    <?php if ($params->get('access-view')) : ?>
        <?php echo LayoutHelper::render('joomla.content.full_image', $this->item); ?>
        <?php
        if (!empty($this->item->pagination) && !$this->item->paginationposition && !$this->item->paginationrelative) :
            echo $this->item->pagination;
        endif;
        ?>
        <?php if (isset($this->item->toc)) :
            echo $this->item->toc;
        endif; ?>
    
    <!-- Affichage du contenu avec transformation DSFR des tableaux -->
    <div class="com-content-article__body">
        <?php 
        // Application de la fonction DSFR sur le contenu complet de l'article
        echo enrichirTableDSFR($this->item->text); 
        ?>
    </div>

        <?php if ($info == 1 || $info == 2) : ?>
            <?php if ($useDefList) : ?>
                <?php echo LayoutHelper::render('joomla.content.info_block', ['item' => $this->item, 'params' => $params, 'position' => 'below']); ?>
            <?php endif; ?>
            <?php if ($params->get('show_tags', 1) && !empty($this->item->tags->itemTags)) : ?>
                <?php $this->item->tagLayout = new FileLayout('joomla.content.tags'); ?>
                <?php echo $this->item->tagLayout->render($this->item->tags->itemTags); ?>
            <?php endif; ?>
        <?php endif; ?>

        <?php
        if (!empty($this->item->pagination) && $this->item->paginationposition && !$this->item->paginationrelative) :
            echo $this->item->pagination;
            ?>
        <?php endif; ?>
        <?php if ((int) $params->get('urls_position', 0) === 1) : ?>
            <?php echo $this->loadTemplate('links'); ?>
        <?php endif; ?>
        <?php // Optional teaser intro text for guests ?>
    <?php elseif ($params->get('show_noauth') == true && $user->guest) : ?>
        <?php echo LayoutHelper::render('joomla.content.intro_image', $this->item); ?>
        <?php 
        // Application de la fonction DSFR sur le texte d'accroche (carte du format blog)
        echo enrichirTableDSFR(HTMLHelper::_('content.prepare', $this->item->introtext)); 
        ?>
        <?php // Optional link to let them register to see the whole article. ?>
        <?php if ($params->get('show_readmore') && $this->item->fulltext != null) : ?>
            <?php $menu = Factory::getApplication()->getMenu(); ?>
            <?php $active = $menu->getActive(); ?>
            <?php $itemId = $active->id; ?>
            <?php $link = new Uri(Route::_('index.php?option=com_users&view=login&Itemid=' . $itemId, false)); ?>
            <?php $link->setVar('return', base64_encode(RouteHelper::getArticleRoute($this->item->slug, $this->item->catid, $this->item->language))); ?>
            <?php echo LayoutHelper::render('joomla.content.readmore', ['item' => $this->item, 'params' => $params, 'link' => $link]); ?>
        <?php endif; ?>
    <?php endif; ?>
    <?php
    if (!empty($this->item->pagination) && $this->item->paginationposition && $this->item->paginationrelative) :
        echo $this->item->pagination;
        ?>
    <?php endif; ?>
    <?php // Content is generated by content plugin event "onContentAfterDisplay" ?>
    <?php echo $this->item->event->afterDisplayContent; ?>
</div>