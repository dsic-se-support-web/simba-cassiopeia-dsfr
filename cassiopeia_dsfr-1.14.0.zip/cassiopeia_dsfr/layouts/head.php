<?php
defined('_JEXEC') or die;
?>

<head>
<!-- BEGIN - RGAA - Affichage du [titre de la page]-[nom du site] dans l'onglet avec prise en compte de la page de résultat de recherches -->
<?php
use Joomla\CMS\Factory;

$app = Factory::getApplication();
$menu = $app->getMenu();
$doc = Factory::getDocument();
$sitename = $app->get('sitename');

$input = $app->input;
$option = $input->getCmd('option', '');
$view = $input->getCmd('view', '');
$searchword = $input->getString('searchword', '');

// On essaie d'avoir le titre du menu actif
$active = $menu->getActive();
$title = '';

if ($active) {
    $title = $active->title;
}

// Cas spécial : page de résultats de recherche
if ($option === 'com_search' && $view === 'search') {
    if ($searchword) {
        $title = 'Résultats de recherche pour : ' . htmlspecialchars($searchword, ENT_QUOTES, 'UTF-8');
    } else {
        $title = 'Résultats de recherche';
    }
} elseif ($option === 'com_finder' && $view === 'search') {
    // Utilisation de com_finder
    if ($searchword) {
        $title = 'Résultats de recherche avancée pour : ' . htmlspecialchars($searchword, ENT_QUOTES, 'UTF-8');
    } else {
        $title = 'Résultats de recherche avancée';
    }
}

// Par défaut, si pas de titre (pas de menu actif, pas de recherche), fallback au titre du document
if (!$title) {
    $title = $doc->getTitle();
}

// On ajoute le nom du site
$title .= ' - ' . $sitename;

// On définit le titre
$doc->setTitle($title);
?>
<!-- END - RGAA - Affichage du [titre de la page]-[nom du site] dans l'onglet avec prise en compte de la page de résultat de recherches -->

    <jdoc:include type="metas" />
    <jdoc:include type="styles" />
    <jdoc:include type="scripts" />

    <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/user.css" />

    <!-- inclusion des fichier du DSFR -->
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="theme-color" content="#000091"><!-- Défini la couleur de thème du navigateur (Safari/Android) -->

    <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/dsfr.min.css">
    <link rel="apple-touch-icon" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/favicon/apple-touch-icon.png"><!-- 180×180 -->
    <link rel="icon" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/favicon/favicon.svg" type="image/svg+xml">
    <link rel="shortcut icon" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/favicon/favicon.ico" type="image/x-icon"><!-- 32×32 -->
    <link rel="manifest" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/favicon/manifest.webmanifest" crossorigin="use-credentials">
    <!-- Modifier les chemins relatifs des favicons en fonction de la structure du projet -->
    <!-- Dans le fichier manifest.webmanifest aussi, modifier les chemins vers les images -->

    <link href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/core/core.min.css" rel="stylesheet">
    <link href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/scheme/scheme.min.css" rel="stylesheet">
    <link href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/utility/utility.min.css" rel="stylesheet">
	<link href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/utility/icons/icons.min.css" rel="stylesheet">


    <!-- <title>Theme DSFR Cabinet DRH</title> -->

</head>