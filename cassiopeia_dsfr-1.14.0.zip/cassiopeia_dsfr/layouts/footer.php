<?php
defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
?>


<?php


if ($this->countModules('dsfrFooter', true)) : ?>

    <footer class="fr-footer" role="contentinfo" id="footer">

    <!-- Liens de menu -->
    <?php if ($this->countModules('dsfrFooter-top', true)) : ?>
      <div class="fr-footer__top">
        <div class="fr-container">
          <div class="fr-grid-row fr-grid-row--start fr-grid-row--gutters">
            <jdoc:include type="modules" name="dsfrFooter-top" style="none" />
          </div>
        </div>
      </div>
    <?php endif; ?>

    <!-- Entête -->
        <div class="fr-container">
            <jdoc:include type="modules" name="dsfrFooter" style="none" />
        </div>
    </footer>

<?php endif; ?>




<?php if ($this->params->get('backTop') == 1) : ?>
    <a href="#top" id="back-top" class="back-to-top-link" aria-label="<?php echo Text::_('TPL_CASSIOPEIA_BACKTOTOP'); ?>">
        <span class="icon-arrow-up icon-fw" aria-hidden="true"></span>
    </a>
<?php endif; ?>


<!-- Début modale paramètres d'affichage (theme claire/sombre) -->
<dialog id="fr-theme-modal" class="fr-modal" role="dialog" aria-labelledby="fr-theme-modal-title">
    <div class="fr-container fr-container--fluid fr-container-md">
        <div class="fr-grid-row fr-grid-row--center">
            <div class="fr-col-12 fr-col-md-6 fr-col-lg-4">
                <div class="fr-modal__body">
					<div class="fr-modal__header">
						<button class="fr-btn--close fr-btn" aria-controls="fr-theme-modal" title="Fermer" id="button-5622" >Fermer</button>
					</div>
                    <div class="fr-modal__content">
						<h2 id="fr-theme-modal-title" class="fr-modal__title"> Paramètres d’affichage </h2>
                        <div id="fr-display" class="fr-display">
              <fieldset class="fr-fieldset" id="display-fieldset" aria-labelledby="display-fieldset-legend display-fieldset-messages">
                <legend class="fr-fieldset__legend--regular fr-fieldset__legend" id="display-fieldset-legend"> Choisissez un thème pour personnaliser l’apparence du site. </legend>
                                <div class="fr-fieldset__element">
                                    <div class="fr-radio-group fr-radio-rich">
                                        <input value="light" type="radio" id="fr-radios-theme-light" name="fr-radios-theme">
                    <label class="fr-label" for="fr-radios-theme-light"> Thème clair </label>
                                        <div class="fr-radio-rich__pictogram">
                                            <svg aria-hidden="true" class="fr-artwork" viewBox="0 0 80 80" width="80px" height="80px">
                                            <use class="fr-artwork-decorative" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/environment/sun.svg#artwork-decorative"></use>
                                            <use class="fr-artwork-minor" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/environment/sun.svg#artwork-minor"></use>
                                            <use class="fr-artwork-major" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/environment/sun.svg#artwork-major"></use>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                                <div class="fr-fieldset__element">
                                    <div class="fr-radio-group fr-radio-rich">
                                        <input value="dark" type="radio" id="fr-radios-theme-dark" name="fr-radios-theme">
                    <label class="fr-label" for="fr-radios-theme-dark"> Thème sombre </label>
                    <div class="fr-radio-rich__pictogram">
                                            <svg aria-hidden="true" class="fr-artwork" viewBox="0 0 80 80" width="80px" height="80px">
                                            <use class="fr-artwork-decorative" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/environment/moon.svg#artwork-decorative"></use>
                                            <use class="fr-artwork-minor" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/environment/moon.svg#artwork-minor"></use>
                                            <use class="fr-artwork-major" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/environment/moon.svg#artwork-major"></use>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
                                <div class="fr-fieldset__element">
                                    <div class="fr-radio-group fr-radio-rich">
                                        <input value="system" type="radio" id="fr-radios-theme-system" name="fr-radios-theme">
                    <label class="fr-label" for="fr-radios-theme-system"> Système <span class="fr-hint-text">Utilise les paramètres système</span>
                    </label>
                                        <div class="fr-radio-rich__pictogram">
                                            <svg aria-hidden="true" class="fr-artwork" viewBox="0 0 80 80" width="80px" height="80px">
                                                <use class="fr-artwork-decorative" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/system/system.svg#artwork-decorative"></use>
                                                <use class="fr-artwork-minor" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/system/system.svg#artwork-minor"></use>
                                                <use class="fr-artwork-major" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/artwork/pictograms/system/system.svg#artwork-major"></use>
                                            </svg>
                                        </div>
                                    </div>
                                </div>
								<div class="fr-messages-group" id="display-fieldset-messages" aria-live="polite">
								</div>
                            </fieldset>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</dialog>
<!-- FIN modale paramètres d'affichage (theme claire/sombre) -->


<?php
