<?php
defined('_JEXEC') or die;
?>


<div id="content" class="couleurDefond">

  <?php if ($this->countModules('banner', true)) : ?>
    <div class="container-banner full-width banner-wrapper" role="complementary" aria-label="bandeau alerte">
      <jdoc:include type="modules" name="banner" style="none" />
    </div>
  <?php else : ?>
    <div class="banner-wrapper empty"></div>
  <?php endif; ?>

  <div class="fr-container">

    <?php if ($this->countModules('top-a', true)) : ?>
      <div class="container-top-a">
        <jdoc:include type="modules" name="top-a" style="card" />
      </div>
    <?php endif; ?>

    <?php if ($this->countModules('top-b', true)) : ?>
      <div class=" container-top-b">
        <jdoc:include type="modules" name="top-b" style="card" />
      </div>
    <?php endif; ?>

    <?php if ($this->countModules('sidebar-left', true)) : ?>
      <div class="grid-child container-sidebar-left">
        <jdoc:include type="modules" name="sidebar-left" style="card" />
      </div>
    <?php endif; ?>



    <!-- Début - coeur de la page ci-dessous -->

    <!-- fil d'ariane -->
    <jdoc:include type="modules" name="dsfrBreadcrumbs" style="none" />

    <jdoc:include type="modules" name="main-top" style="html5" />
  </div>

<!-- Module haut et pleine largeur -->
  <?php if ($this->countModules('main-top-full-width', true)) : ?>
    <div class=" container-main-top-full-width" role="region" aria-label="Article en bandeau">
      <jdoc:include type="modules" name="main-top-full-width" style="none" />
    </div>
  <?php endif; ?>

  <div class="fr-container">
    <jdoc:include type="message" />

    <div class="fr-grid-row">

<!-- Début - Calcul de l'affichage en fonction d'éléments latéraux -->
  <?php
  $hasLeft = $this->countModules('dsfrMenuLateral', true);
  $hasRight = $this->countModules('dsfrSidebar-right', true);

  if ($hasLeft && $hasRight) {
      $contentClass = 'fr-col-md-6';  // 3 + 6 + 3 = 12 colonnes
  } elseif ($hasLeft || $hasRight) {
      $contentClass = 'fr-col-md-9';  // 3 + 9 ou 9 + 3
  } else {
      $contentClass = 'fr-col-12';
  }
  ?>
<!-- Fin - Calcul de l'affichage en fonction d'éléments latéraux -->

  <?php if ($hasLeft) : ?><!-- Menu latéral gauche -->
    <div class="fr-col-12 fr-col-md-3 fr-mb-3w">
      <jdoc:include type="modules" name="dsfrMenuLateral" style="none" />
    </div>
  <?php endif; ?>

  <div class="<?= $contentClass ?> fr-col-12">
    <main role="main">
      <jdoc:include type="component" />
    </main>
  </div>

  <?php if ($hasRight) : ?> <!-- Bloc module en latéral droit -->
    <div class="fr-col-12 fr-col-md-3 fr-mb-3w">
      <jdoc:include type="modules" name="dsfrSidebar-right" style="card" />
    </div>
  <?php endif; ?>

</div>


    <jdoc:include type="modules" name="main-bottom" style="html5" />
    
    <!-- Fin - coeur de la page ci-dessous -->



    <?php if ($this->countModules('sidebar-right', true)) : ?>
      <!--<div class="grid-child container-sidebar-right">
        <jdoc:include type="modules" name="sidebar-right" style="card" />
      </div>-->
    <?php endif; ?>

    <?php if ($this->countModules('bottom-a', true)) : ?>
      <div class=" container-bottom-a">
        <jdoc:include type="modules" name="bottom-a" style="none" />
      </div>
    <?php endif; ?>

    <?php if ($this->countModules('bottom-b', true)) : ?>
      <div class=" container-bottom-b">
        <jdoc:include type="modules" name="bottom-b" style="card" />
      </div>
    <?php endif; ?>

  </div>

<!-- Module bas et pleine largeur -->
  <?php if ($this->countModules('bottom-b-full-width', true)) : ?>
    <div class=" container-bottom-b-full-width">
      <jdoc:include type="modules" name="bottom-b-full-width" style="none" />
    </div>
  <?php endif; ?>

<!-- Module social -->
  <?php if ($this->countModules('dsfrSocial', true)) : ?>
    <div class="fr-follow bandeauSocial">
      <div class="fr-container" role="region" aria-label="Bandeau social">
        <div class="fr-grid-row">

          <jdoc:include type="modules" name="dsfrSocial" style="none" />

        </div>
      </div>
    </div>
  <?php endif; ?>

  <?php
