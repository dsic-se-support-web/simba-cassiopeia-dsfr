<?php
defined('_JEXEC') or die;

?>

<div class="fr-skiplinks">
  <nav role="navigation" aria-label="Accès rapide" class="fr-container">
    <ul class="fr-skiplinks__list">
      <li>
        <a class="fr-link" href="#content">Contenu</a>
      </li>
      <li>
        <a class="fr-link" href="#menu">Menu</a>
      </li>
      <li>
        <a class="fr-link" href="#search">Recherche</a>
      </li>
      <li>
        <a class="fr-link" href="#footer">Pied de page</a>
      </li>
    </ul>
  </nav>
</div>

<header role="banner" class="fr-header  full-width<?php echo $stickyHeader ? ' ' . $stickyHeader : ''; ?>">

    <?php if ($this->countModules('dsfrHeader')) : ?>
        <div class="fr-header__body">
            <div class="fr-container">
                <div class="fr-header__body-row">
                    <!-- Tout les module du header sont afficher ici grace a la baslise ci-dessous  -->
                    <jdoc:include type="modules" name="dsfrHeader" style="none" />
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if ($this->countModules('search', true)) : ?>
        <div class="container-search">
            <jdoc:include type="modules" name="search" style="none" />
        </div>
    <?php endif; ?>

    <!-- menu principal du site -->
    <?php if ($this->countModules('menu', true) || $this->countModules('search', true)) : ?>
        <div class="fr-header__menu fr-modal" id="modal-577" aria-labelledby="button-578">
        <!-- <div class="fr-header__menu fr-modal" id="menu"> -->
            <div class="fr-container">
                <button class="fr-btn--close fr-btn" aria-controls="modal-577" title="Fermer">
                    Fermer
                </button>
                <div class="fr-header__menu-links">
                </div>
                <?php if ($this->countModules('menu', true)) : ?>
                    <jdoc:include type="modules" name="menu" style="none" />
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>


    <!-- fin -->

    <!-- Les balise ci-dessous ne nous sont pas utile, ce sont les positions de joomla -->
    <?php if ($this->countModules('topbar')) : ?>
        <div class="container-topbar">
            <jdoc:include type="modules" name="topbar" style="none" />
        </div>
    <?php endif; ?>

    <?php if ($this->countModules('below-top')) : ?>
        <div class="grid-child container-below-top">
            <jdoc:include type="modules" name="below-top" style="none" />
        </div>
    <?php endif; ?>

    <?php if ($this->params->get('brand', 1)) : ?>
        <div class="grid-child">
            <div class="navbar-brand">
                <a class="brand-logo" href="<?php echo $this->baseurl; ?>/">
                    <?php echo $logo; ?>
                </a>
                <?php if ($this->params->get('siteDescription')) : ?>
                    <div class="site-description"><?php echo htmlspecialchars($this->params->get('siteDescription')); ?></div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
    <!-- Fin des balise de joomla -->


</header>

<?php
