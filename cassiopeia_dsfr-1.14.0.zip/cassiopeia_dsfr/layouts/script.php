<?php
defined('_JEXEC') or die;
?>

<script>
    // Désactivation du démarrage automatique du DSFR
    window.dsfr = {
        verbose: false,
        mode: 'loaded'
    };
</script>
<script type="module" src="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/dsfr.module.min.js"></script>
<script type="text/javascript" nomodule src="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/dsfr.nomodule.min.js"></script>


<script>
    document.addEventListener('DOMContentLoaded', () => {
        dsfr.start()
        console.log('dsfr manual start')
        document.dispatchEvent(new Event("template.ready"))
    })
</script>