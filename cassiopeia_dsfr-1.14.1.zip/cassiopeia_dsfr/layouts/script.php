<?php
defined('_JEXEC') or die;
?>

<script>
    // Désactivation du démarrage automatique du DSFR
    window.dsfr = {
        verbose: false,
        mode: 'loaded'
    };
</script>
<script type="module" src="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/dsfr.module.min.js"></script>
<script type="text/javascript" nomodule src="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/dsfr.nomodule.min.js"></script>


<script>
    document.addEventListener('DOMContentLoaded', () => {
        dsfr.start()
        console.log('dsfr manual start')
        document.dispatchEvent(new Event("template.ready"))
    })
</script>

<script>
// Apparition/disparition du lien de retour au haut de page selon le scroll up ou down
document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('back-to-top');

    if (!btn) return;

    // Apparition au scroll
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            btn.style.display = 'block';
        } else {
            btn.style.display = 'none';
        }
    });

    // Scroll vers le haut
    btn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});
</script>