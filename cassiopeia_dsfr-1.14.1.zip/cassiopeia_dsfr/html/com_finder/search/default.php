<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_finder
 */
defined('_JEXEC') or die;
use Joomla\CMS\Factory;

// Tente de charger les assets standard du Finder
/** @var \Joomla\Component\Finder\Site\View\Search\HtmlView $this */
$this->getDocument()->getWebAssetManager()
    ->useStyle('com_finder.finder')
    ->useScript('com_finder.finder');

// Récupération des paramètres de pagination
$app = Factory::getApplication();
$input = $app->input;
$limitstart = $input->get('limitstart', 0, 'uint');
$limit = 5; // Nombre d'articles par page

// Récupération des filtres de dates
$createdArray = $input->get('created', [], 'array');
$dateMin = isset($createdArray['min']) ? $createdArray['min'] : $input->get('d1', '', 'string');
$dateMax = isset($createdArray['max']) ? $createdArray['max'] : $input->get('d2', '', 'string');
?>



<div class="com-finder finder">
    <?php if ($this->params->get('show_page_heading')) : ?>
        <h1>
            <?= $this->escape($this->params->get('page_heading') ?: $this->params->get('page_title')); ?>
        </h1>
    <?php endif; ?>

    <div class="fr-grid-row fr-grid-row--gutters">
        <div class="fr-col-12 fr-col-lg-4">
            <div id="search-form" class="com-finder__form fr-mb-4w">
                <?= $this->loadTemplate('form'); ?>
            </div>
        </div>

        <div class="fr-col-12 fr-col-lg-8">
            <?php if ($this->query->search === true) : ?>
                <div id="search-results" class="com-finder__results">
                    <?php if (!empty($this->results)) : ?>
                        <?php
                        // AJOUT : FILTRAGE PAR DATES DES RÉSULTATS FINDER
                        if (!empty($dateMin) || !empty($dateMax)) {
                            $filteredResults = [];

                            foreach ($this->results as $result) {
                                // Récupérer la date de publication du résultat
                                $itemDate = '';

                                // Essayer différentes propriétés de date
                                if (isset($result->start_date) && $result->start_date) {
                                    $itemDate = substr($result->start_date, 0, 10);
                                } elseif (isset($result->publish_start_date) && $result->publish_start_date) {
                                    $itemDate = substr($result->publish_start_date, 0, 10);
                                } elseif (isset($result->created) && $result->created) {
                                    $itemDate = substr($result->created, 0, 10);
                                }

                                // Vérifier si la date est dans la plage
                                $includeResult = true;

                                if (!empty($dateMin) && !empty($itemDate) && $itemDate < $dateMin) {
                                    $includeResult = false;
                                }

                                if (!empty($dateMax) && !empty($itemDate) && $itemDate > $dateMax) {
                                    $includeResult = false;
                                }

                                if ($includeResult) {
                                    $filteredResults[] = $result;
                                }
                            }

                            $this->results = $filteredResults;
                        }

                        // Limiter à 20 articles après filtrage
                        $this->results = array_slice($this->results, 0, 20);
                        ?>

                        <?php if (!empty($dateMin) || !empty($dateMax)) : ?>
                            <div class="fr-alert fr-alert--info fr-mb-3w">
                                <p class="fr-alert__title">Filtrage actif</p>
                                <p>
                                    <?php if (!empty($dateMin)) : ?>
                                        Du <strong><?= date('d/m/Y', strtotime($dateMin)); ?></strong>
                                    <?php endif; ?>
                                    <?php if (!empty($dateMax)) : ?>
                                        au <strong><?= date('d/m/Y', strtotime($dateMax)); ?></strong>
                                    <?php endif; ?>
                                    <br>
                                    <small><?= count($this->results); ?> résultat(s) trouvé(s)</small>
                                </p>
                            </div>
                        <?php endif; ?>

                        <?= $this->loadTemplate('results'); ?>
                    <?php else : ?>
                        <div class="fr-alert fr-alert--warning">
                            <h3 class="fr-alert__title">Aucun résultat</h3>
                            <p>Nous sommes désolés, aucun résultat ne correspond à votre recherche. Veuillez modifier ou réinitialiser les filtres.</p>
                        </div>
                        <script>
                            console.info('Aucun résultat Finder.');
                        </script>
                    <?php endif; ?>
                </div>
            <?php else : ?>
                <?php
                $db = Factory::getDbo();

                // Requête pour compter le total d'articles
                $countQuery = $db->getQuery(true)
                    ->select('COUNT(*)')
                    ->from('#__content')
                    ->where('state = 1');

                // AJOUT : Filtrage par dates pour les articles par défaut
                if (!empty($dateMin)) {
                    $countQuery->where('created >= ' . $db->quote($dateMin . ' 00:00:00'));
                }
                if (!empty($dateMax)) {
                    $countQuery->where('created <= ' . $db->quote($dateMax . ' 23:59:59'));
                }

                $db->setQuery($countQuery);
                $total = $db->loadResult();

                // Requête principale avec limitation
                $query = $db->getQuery(true)
                    ->select(['id', 'title', 'introtext', 'images', 'created'])
                    ->from('#__content')
                    ->where('state = 1');

                // AJOUT : Même filtrage pour la requête principale
                if (!empty($dateMin)) {
                    $query->where('created >= ' . $db->quote($dateMin . ' 00:00:00'));
                }
                if (!empty($dateMax)) {
                    $query->where('created <= ' . $db->quote($dateMax . ' 23:59:59'));
                }

                $query->order('created DESC')
                    ->setLimit($limit, $limitstart);
                $db->setQuery($query);
                $articles = $db->loadObjectList();
                ?>

                <?php if (!empty($articles)) : ?>
                    <?php if (!empty($dateMin) || !empty($dateMax)) : ?>
                       <div role="notice" class="fr-notice fr-notice--info fr-notice--no-icon fr-mb-3w">
                          <div class="fr-container">
                            <div class="fr-notice__body">
                               <p class="fr-alert__title">Filtrage actif</p>
                               <p>
                                  <span class="fr-notice__title">
                                     <?php if (!empty($dateMin)) : ?>
                                        Du <strong><?= date('d/m/Y', strtotime($dateMin)); ?></strong>
                                     <?php endif; ?>

                                     <?php if (!empty($dateMax)) : ?>
                                        au <strong><?= date('d/m/Y', strtotime($dateMax)); ?></strong>
                                     <?php endif; ?>
                                  </span>
                               </p>
                            </div>
                          </div>
                       </div>
                    <?php endif; ?>

                    <div class="d-flex justify-content-between align-items-center fr-mb-3w">
                        <h3>Derniers articles publiés</h3>
                        <p class="fr-text--sm fr-mb-0">
                            Affichage de <?= $limitstart + 1 ?> à <?= min($limitstart + $limit, $total) ?> sur <?= $total ?> résultat<?= $total > 1 ? 's' : '' ?>
                        </p>
                    </div>

                    <div class="fr-grid-row fr-grid-row--gutters">
                        <?php foreach ($articles as $article) : ?>
                            <?php
                            $articleImage = '';
                            if (!empty($article->images)) {
                                $images = json_decode($article->images, true);
                                $articleImage = $images['image_intro'] ?? '';
                            }

                            $dateFormatted = '';
                            if (!empty($article->created)) {
                                $date = new DateTime($article->created);
                                $dateFormatted = $date->format('d/m/Y');
                            }
                            ?>
                            <div class="fr-col-12 fr-mb-2w">
								<div class="fr-card fr-enlarge-link fr-card--sm fr-card--horizontal" role="article" aria-labelledby="card-title-<?php echo $i; ?>">
								<?php if ($articleImage) : ?>
									<div class="fr-card__header">
										<div class="fr-card__img">
											<img class="fr-responsive-img"
											src="<?= htmlspecialchars($articleImage) ?>"
											alt="Illustration de l'article <?= htmlspecialchars($article->title) ?>" />
										</div>
									</div>
								<?php else : ?>
									<div class="fr-card__header">
										<div class="fr-card__img">
											<img class="fr-responsive-img"
												src="./images/placeholder.png"
												alt="Illustration de l'article <?= htmlspecialchars($article->title) ?>" />
										</div>
									</div>
								<?php endif; ?>
				
									<div class="fr-card__body">
										<div class="fr-card__content">
											<h3 id="card-title-<?php echo $i; ?>" class="fr-card__title">
												<a href="<?= 'index.php?option=com_content&view=article&id=' . $article->id ?>"
												class="fr-card__link">
													<?= htmlspecialchars($article->title) ?>
												</a>
											</h3>

										<?php if ($dateFormatted) : ?>
											<p class="fr-card__detail fr-text--sm fr-mb-1w">
												<span class="fr-icon-calendar-line fr-icon--sm" aria-hidden="true"></span>
												<?= $dateFormatted ?>
											</p>
										<?php endif; ?>
						
											<p class="fr-card__desc"><?= htmlspecialchars(substr(strip_tags($article->introtext), 0, 100)) ?></p>

										</div>
									</div>
								</div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($total > $limit) : ?>
                        <nav role="navigation" class="fr-pagination fr-mt-4w" aria-label="Pagination">
                            <ul class="fr-pagination__list pager__items js-pager__items">
                                <?php
                                $currentPage = floor($limitstart / $limit);
                                $totalPages = ceil($total / $limit);
                                $maxPagesToShow = 3;

                                $baseQuery = 'option=com_finder&view=search';
                                $dateParams = (!empty($dateMin) ? '&d1=' . urlencode($dateMin) : '') . (!empty($dateMax) ? '&d2=' . urlencode($dateMax) : '');
                                ?>

							<?php if ($currentPage > 0) : ?>
								<!-- Lien "Première page" -->
								<li>
									<a href="?<?= $baseQuery ?>&limitstart=0<?= $dateParams ?>"
									class="fr-pagination__link fr-pagination__link--first"
									aria-label="Première page">
										Première page
									</a>
								</li>

								<!-- Lien "Page précédente" -->
								<?php $prevStart = ($currentPage - 1) * $limit; ?>
								<li>
									<a href="?<?= $baseQuery ?>&limitstart=<?= $prevStart ?><?= $dateParams ?>"
									class="fr-pagination__link fr-pagination__link--prev fr-pagination__link--lg-label"
									aria-label="Page précédente">
										Page précédente
									</a>
								</li>
							<?php endif; ?>

                            <?php
								$startPage = max(0, $currentPage - 1);
                                $endPage = min($totalPages - 1, $startPage + $maxPagesToShow - 1);

                                for ($i = $startPage; $i <= $endPage; $i++) :
                                    $pageStart = $i * $limit;
                                    $isActive = ($limitstart == $pageStart);
                            ?>
								<li class="pager__item<?= $isActive ? ' is-active' : '' ?>">
									<a href="?<?= $baseQuery ?>&limitstart=<?= $pageStart ?><?= $dateParams ?>"
                                    title="Aller à la page <?= $i + 1 ?>"
                                    aria-label="Page <?= $i + 1 ?>"
                                    class="fr-pagination__link"
                                    <?= $isActive ? 'aria-current="page"' : '' ?>>
                                        <?= $i + 1 ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

							<?php if ($currentPage < $totalPages - 1) : ?>
								<?php if ($endPage < $totalPages - 1) : ?>
								<li class="pager__item pager__item--ellipsis" role="presentation">
									<span class="fr-pagination__link fr-displayed-lg">…</span>
								</li>
								<?php endif; ?>

								<!-- Lien "Page suivante" -->
								<li>
									<a href="?<?= $baseQuery ?>&limitstart=<?= ($currentPage + 1) * $limit ?><?= $dateParams ?>"
									class="fr-pagination__link fr-pagination__link--next fr-pagination__link--lg-label"
									aria-label="Page suivante">
										Page suivante
									</a>
								</li>

								<!-- Lien "Dernière page" si ce n’est pas déjà l’avant-dernière page -->
								<?php if ($currentPage < $totalPages - 2) : ?>
									<li>
										<a href="?<?= $baseQuery ?>&limitstart=<?= ($totalPages - 1) * $limit ?><?= $dateParams ?>"
										class="fr-pagination__link fr-pagination__link--last"
										aria-label="Dernière page">
											Dernière page
										</a>
									</li>
								<?php endif; ?>
							<?php endif; ?>
                               

                            </ul>
                        </nav>
                    <?php endif; ?>

                <?php else : ?>
                    <div class="fr-alert fr-alert--info">
                        <p>Aucun article disponible pour la période sélectionnée.</p>
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        </div>
    </div>
</div>