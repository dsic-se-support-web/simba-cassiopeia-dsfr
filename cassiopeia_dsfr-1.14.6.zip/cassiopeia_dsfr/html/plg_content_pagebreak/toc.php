<?php

/**
 * @package     Joomla.Plugin
 * @subpackage  Content.pagebreak
 *
 * @copyright   (C) 2018 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Router\Route;

// Récupération du paramètre du template
$app   = JFactory::getApplication();
$template = $app->getTemplate(true);
$params = $template->params;
$tocPos = $params->get('tocPosition', 'left');   // valeur par défaut = left

// Construction de la classe de position
$positionClass = ($tocPos === 'right')
    ? 'float-end article-index ms-3 mb-3'    // classe d'alignement à droite
    : 'float-start article-index me-3 mb-3'; // classe d'alignement à gauche

// Ajout du style inline
$style = ($tocPos === 'right')
    ? 'border-right: solid 2px #ddd;padding-right: 10px;margin-right: 15px;'
    : 'border-left: solid 2px #ddd;padding-left: 10px;margin-left: 15px;';
?>

<div class="<?php echo $positionClass; ?> fr-col-lg-3 fr-col-12" style="<?php echo $style; ?>">
    <nav class="fr-summary" role="navigation" aria-labelledby="fr-summary-title">
			<?php if ($headingtext) : ?>
			<h2 class="fr-summary__title" id="fr-summary-title"><?php echo $headingtext; ?></h2>
			<?php endif; ?>
			
			<ol>
			<?php foreach ($list as $listItem) : ?>
			<?php $class = $listItem->active ? ' active' : ''; ?>
				<li>
					<a class="fr-summary__link" id="summary-link-1" href="<?php echo Route::_($listItem->link); ?>"><?php echo $listItem->title; ?></a>
				</li>
			<?php endforeach; ?>
			</ol>
			
		</nav>
</div>