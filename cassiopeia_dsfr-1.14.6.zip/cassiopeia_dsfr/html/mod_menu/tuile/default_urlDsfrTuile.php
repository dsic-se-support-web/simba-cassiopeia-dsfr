<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_menu
 *
 * @copyright   (C) 2009 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Filter\OutputFilter;

$attributes = [];

if ($item->anchor_title) {
    $attributes['title'] = $item->anchor_title;
}

if ($item->anchor_css) {
    $attributes['class'] = $item->anchor_css;
}

if ($item->anchor_rel) {
    $attributes['rel'] = $item->anchor_rel;
}

$linktype = $item->title;

if ($item->menu_icon) {
    // The link is an icon
    if ($itemParams->get('menu_text', 1)) {
        //MODIFICATION PAR MATHIEU CI-DESSOUS
        // If the link text is to be displayed, the icon is added with aria-hidden 
        $linktype = '<span class="p-2 ' . $item->menu_icon . '" aria-hidden="true"></span>';
    } else {
        // If the icon itself is the link, it needs a visually hidden text
        $linktype = '<span class="p-2 ' . $item->menu_icon . '" aria-hidden="true"></span><span class="visually-hidden"> </span>';
    }
} elseif ($item->menu_image) {
    // The link is an image, maybe with an own class
    $image_attributes = [];

    if ($item->menu_image_css) {
        $image_attributes['class'] = $item->menu_image_css;
    }

    $linktype = HTMLHelper::_('image', $item->menu_image, $item->title, $image_attributes);

    if ($itemParams->get('menu_text', 1)) {
        $linktype .= '<span class="image-title">' . $item->title . '</span>';
    }
}

if ($item->browserNav == 1) {
    $attributes['target'] = '_blank';
    $attributes['rel'] = 'noopener noreferrer';

    if ($item->anchor_rel == 'nofollow') {
        $attributes['rel'] .= ' nofollow';
    }
} elseif ($item->browserNav == 2) {
    $options = 'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,' . $params->get('window_open');

    $attributes['onclick'] = "window.open(this.href, 'targetWindow', '" . $options . "'); return false;";
}



// echo HTMLHelper::_('link', OutputFilter::ampReplace(htmlspecialchars($item->flink, ENT_COMPAT, 'UTF-8', false)), $linktype, $attributes);
////////////
//////////// NE PAS OUBLIÉ D'AJOUTÉ LA CLASSE
?>

<div class="fr-tile fr-tile--sm fr-enlarge-link fr-mr-2v tuileCustom" id="tile-<?php echo $item->id ?>">
    <div class="fr-tile__body">
        <div class="fr-tile__content">
            <h3 class="fr-tile__title">
                <a href="<?php echo $item->flink ?>" <?php foreach ($attributes as $key => $value) {
    echo $key . '="' . htmlspecialchars($value, ENT_QUOTES, 'UTF-8') . '" ';
                                                        } ?>> <?php echo $item->title ?>
<?php if (($attributes['target'] ?? '') === '_blank') {
    echo '<span class="fr-sr-only">nouvelle fenêtre</span>';
} ?>
                </a>
            </h3>
        </div>
    </div>
    <div class="fr-tile__header">
       <div class="fr-tile__pictogram">
         <?php if ($item->menu_icon || $item->menu_image) {
            echo $linktype;
         } ?>
       </div>
    </div>
</div>