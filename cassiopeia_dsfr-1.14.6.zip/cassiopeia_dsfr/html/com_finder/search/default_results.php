<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_finder
 *
 * @copyright   (C) 2011 Open Source Matters, Inc.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;

$app   = Factory::getApplication();
$input = $app->input;
$pagination = $this->pagination;
$limit = 20;
$limitstart = $input->getInt('limitstart', 0);
$total = (int) $pagination->total;
$currentPage = max(1, floor($limitstart / $limit) + 1);
$pagesTotal = max(1, (int) ceil($total / $limit));
$pagination->pagesCurrent = $currentPage;
$pagination->pagesTotal = $pagesTotal;
$pagination->pagesStop  = $pagesTotal;

//$displayResults = array_slice($this->results, $limitstart, $limit);
$displayResults = $this->results;
?>

<?php // Affichage des suggestions ou des reformulations de recherche ?>
<?php if (($this->suggested && $this->params->get('show_suggested_query', 1)) || ($this->explained && $this->params->get('show_explained_query', 1))) : ?>
    <div id="search-query-explained" class="com-finder__explained">
        <?php if ($this->suggested && $this->params->get('show_suggested_query', 1)) : ?>
            <?php
                $uri = Uri::getInstance($this->query->toUri());
                $uri->setVar('q', $this->suggested);
                $uri->setVar('limit', $limit);
                $linkUrl = Route::_($uri->toString(['path', 'query']));
                $link = '<a href="' . $linkUrl . '">' . $this->escape($this->suggested) . '</a>';
                echo Text::sprintf('COM_FINDER_SEARCH_SIMILAR', $link);
            ?>
        <?php elseif ($this->explained && $this->params->get('show_explained_query', 1)) : ?>
            <p role="alert">
                <?php $explained = str_replace(' est requis', '', $this->explained);
                  echo Text::plural('COM_FINDER_QUERY_RESULTS', $total, $explained); ?>
            </p>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php // Tri des résultats ?>
<?php if ($this->params->get('show_sort_order', 0) && !empty($this->sortOrderFields) && !empty($this->results)) : ?>
    <div id="search-sorting" class="com-finder__sorting">
        <?php echo $this->loadTemplate('sorting'); ?>
    </div>
<?php endif; ?>

<?php // Activation du surlignage des termes recherchés ?>
<?php if (!empty($this->query->highlight) && $this->params->get('highlight_terms', 1)) : ?>
    <?php
        $this->document->getWebAssetManager()->useScript('highlight');
        $this->document->addScriptOptions(
            'highlight',
            [[
                'class'     => 'js-highlight',
                'highLight' => array_slice($this->query->highlight, 0, 10),
            ]]
        );
    ?>
<?php endif; ?>

<?php if (!empty($this->results)) : ?>

    <ul id="search-result-list" class="js-highlight com-finder__results-list" start="<?php echo $limitstart + 1; ?>">
        <?php
        $this->baseUrl = Uri::getInstance()->toString(['scheme', 'host', 'port']);
        foreach ($displayResults as $i => $result) :
            $this->result = &$result;
            $this->result->counter = $limitstart + $i + 1; // Correction pour afficher le bon numéro d'index sur la page 2, 3, etc.
            $layout = $this->getLayoutFile($this->result->layout);
            echo $this->loadTemplate($layout);
        endforeach;
        ?>
    </ul>

    <div class="com-finder__navigation search-pagination">

        <?php if ($pagesTotal > 1) : ?>
            <nav role="navigation" class="fr-pagination" aria-label="<?php echo Text::_('JLIB_HTML_PAGINATION'); ?>">
                <ul class="fr-pagination__list">

                    <?php
                    // Lien "Première page" (|<)
                    if ($currentPage > 1) :
                        $uriFirst = clone Uri::getInstance();
                        $uriFirst->setVar('limitstart', 0);
                        $linkFirst = Route::_($uriFirst->toString());
                        echo '<li><a aria-label="Première page" class="fr-pagination__link fr-pagination__link--first" href="' . $linkFirst . '" >Première page</a></li>';
                    endif;

                    // Lien "Page précédente" (< Page précédente)
                    if ($currentPage > 1) :
                        $uriPrev = clone Uri::getInstance();
                        $uriPrev->setVar('limitstart', ($currentPage - 2) * $limit);
                        $linkPrev = Route::_($uriPrev->toString());
                        echo '<li><a class="fr-pagination__link fr-pagination__link--prev fr-pagination__link--lg-label" aria-label="Page précédente" href="' . $linkPrev . '" >Page précédente</a></li>';
                    endif;

                    // Déterminer quelles pages afficher (avec ellipses)
                    $maxToShow = 3;
                    $startPage = max(1, $currentPage - 1);
                    $endPage   = min($pagesTotal, $currentPage + 1);

                    if ($pagesTotal > $maxToShow && $startPage > 2) {
                        $firstUri = clone Uri::getInstance();
                        $firstUri->setVar('limitstart', 0);
                        echo '<li><a class="fr-pagination__link" href="' . Route::_($firstUri->toString()) . '">1</a></li>';
                        echo '<li class="fr-pagination__item fr-pagination__item--disabled"><span class="fr-pagination__link fr-hidden fr-unhidden-lg">…</span></li>';
                    }

                    // Pages visibles
                    for ($i = $startPage; $i <= $endPage; $i++) :
                        $uri = clone Uri::getInstance();
                        $uri->setVar('limitstart', ($i - 1) * $limit);
                        $link = Route::_($uri->toString());
                        //$isCurrent = ($i === $currentPage);
                        $isCurrent = ($i == $currentPage);
                        $class = $isCurrent ? 'fr-pagination__link fr-pagination__link--current' : 'fr-pagination__link';
                        $aria = $isCurrent ? ' aria-current="page"' : '';
                        echo '<li><a class="' . $class . '" href="' . $link . '" title="Page ' . $i . '"' . $aria . '>' . $i . '</a></li>';
                    endfor;

                    // Ellipse + dernière page si nécessaire
                    if ($pagesTotal > $maxToShow && $endPage < $pagesTotal - 1) {
                        echo '<li class="fr-pagination__item fr-pagination__item--disabled"><span class="fr-pagination__link fr-hidden fr-unhidden-lg">…</span></li>';
                        $lastUriNum = clone Uri::getInstance();
                        $lastUriNum->setVar('limitstart', ($pagesTotal - 1) * $limit);
                        echo '<li><a class="fr-pagination__link" href="' . Route::_($lastUriNum->toString()) . '">' . $pagesTotal . '</a></li>';
                    }

                    // Lien "Page suivante" (Page suivante >)
                    if ($currentPage < $pagesTotal) :
                        $uriNext = clone Uri::getInstance();
                        $uriNext->setVar('limitstart', $limitstart + $limit);
                        $linkNext = Route::_($uriNext->toString());
                        echo '<li><a class="fr-pagination__link fr-pagination__link--next fr-pagination__link--lg-label" aria-label="Page suivante" href="' . $linkNext . '" >Page suivante</a></li>';
                    endif;

                    // Lien "Dernière page" (>|)
                    if ($currentPage < $pagesTotal) :
                        $uriLast = clone Uri::getInstance();
                        $uriLast->setVar('limitstart', ($pagesTotal - 1) * $limit);
                        $linkLast = Route::_($uriLast->toString());
                        echo '<li><a class="fr-pagination__link fr-pagination__link--last" aria-label="Dernière page" href="' . $linkLast . '">Dernière page</a></li>';
                    endif;
                    ?>

                </ul>
            </nav>
        <?php endif; ?>

        <?php if ($this->params->get('show_pagination_results', 1)) : ?>
            <div class="fr-text--sm fr-mt-2w search-pages-counter text-center">
                <?php
                $start = $total ? $limitstart + 1 : 0;
                // CORRECTION : Utiliser la variable $limit au lieu de count($this->results) pour le calcul de la fin de page
                $end = min($limitstart + count($displayResults), $total);
                echo Text::sprintf('COM_FINDER_SEARCH_RESULTS_OF', $start, $end, $total);
                ?>
            </div>
        <?php endif; ?>

    </div>

<?php else : ?>
    <div id="search-result-empty" class="com-finder__empty">
        <p>
            <?php echo Text::sprintf('La recherche "%s" n\'a donné aucun résultat.', $this->escape($this->query->input)); ?>
        </p>
    </div>
<?php endif; ?>