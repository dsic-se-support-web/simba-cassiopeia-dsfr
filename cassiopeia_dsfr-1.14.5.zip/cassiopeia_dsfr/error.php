<?php

/**
 * @package     Joomla.Site
 * @subpackage  Template.system
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

/** @var Joomla\CMS\Document\ErrorDocument  $this */

if (!isset($this->error)) {
    $this->error = new Exception(Text::_('JERROR_ALERTNOAUTHOR'));
    $this->debug = false;
}

// Load template CSS file
$this->getWebAssetManager()->registerAndUseStyle('template.system.error', 'media/system/css/system-site-error.css');

if ($this->direction === 'rtl') {
    $this->getWebAssetManager()->registerAndUseStyle('template.system.error_rtl', 'media/system/css/system-site-error_rtl.css');
}

// Set page title
$this->setTitle($this->error->getCode() . ' - ' . htmlspecialchars($this->error->getMessage(), ENT_QUOTES, 'UTF-8'));

// Get the error code
$errorCode = $this->error->getCode();
?>

<html lang="fr-fr" dir="ltr" data-fr-scheme="light" data-fr-js="true" data-fr-theme="light">

<head>
    <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/user.css" />

    <!-- inclusion des fichier du DSFR -->
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="theme-color" content="#000091"><!-- Défini la couleur de thème du navigateur (Safari/Android) -->

    <link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/dsfr.min.css">
    <link rel="apple-touch-icon" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/favicon/apple-touch-icon.png"><!-- 180×180 -->
    <link rel="icon" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/favicon/favicon.svg" type="image/svg+xml">
    <link rel="shortcut icon" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/favicon/favicon.ico" type="image/x-icon"><!-- 32×32 -->
    <link rel="manifest" href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/favicon/manifest.webmanifest" crossorigin="use-credentials">
    <!-- Modifier les chemins relatifs des favicons en fonction de la structure du projet -->
    <!-- Dans le fichier manifest.webmanifest aussi, modifier les chemins vers les images -->

    <link href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/core/core.min.css" rel="stylesheet">
    <link href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/scheme/scheme.min.css" rel="stylesheet">
    <link href="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/utility/utility.min.css" rel="stylesheet">

</head>



<?php require('layouts/header.php') ?>

<?php if ($this->countModules('error-' . $errorCode)) : ?>
    <jdoc:include type="modules" name="error-<?php echo $errorCode; ?>" style="none" />
<?php endif  ?>


<?php require('layouts/footer.php') ?>



<?php require('layouts/script.php') ?>


<jdoc:include type="modules" name="debug" style="none" />


</html>