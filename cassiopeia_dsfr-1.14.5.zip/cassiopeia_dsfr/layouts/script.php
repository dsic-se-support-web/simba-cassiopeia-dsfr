<?php
defined('_JEXEC') or die;
?>

<script>
    // Désactivation du démarrage automatique du DSFR
    window.dsfr = {
        verbose: false,
        mode: 'loaded'
    };
</script>
<script type="module" src="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/dsfr.module.min.js"></script>
<script type="text/javascript" nomodule src="<?php echo $this->baseurl ?>/templates/cassiopeia_dsfr/dsfr/dsfr.nomodule.min.js"></script>


<script>
    document.addEventListener('DOMContentLoaded', () => {
        dsfr.start()
        console.log('dsfr manual start')
        document.dispatchEvent(new Event("template.ready"))
    })
</script>

<script>
// Apparition/disparition du lien de retour au haut de page selon le scroll up ou down
document.addEventListener('DOMContentLoaded', function () {
    const btn = document.getElementById('back-to-top');

    if (!btn) return;

    // Apparition au scroll
    window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
            btn.style.display = 'block';
        } else {
            btn.style.display = 'none';
        }
    });

    // Scroll vers le haut
    btn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
});
</script>

<script>
  /* Désactivé suite à contre audit RGAA du 17-02-2025
// Icône d' accessiblité
document.addEventListener('DOMContentLoaded', function() {
  // Cache l'icône d'origine s'il existe
  const oldIcon = document.querySelector('i._access-icon._access');
  if (oldIcon) {
    oldIcon.style.display = 'none';
  }

  // Évite les doublons
  if (!document.getElementById('custom-access-btn')) {
    // Création du bouton personnalisé
    const newBtn = document.createElement('button');
    newBtn.id = 'custom-access-btn';
    newBtn.title = 'Options d’accessibilité';
    newBtn.setAttribute('aria-label', 'Options d’accessibilité');
    newBtn.innerHTML = '<i class="fa-solid fa-universal-access"></i>';
    document.body.appendChild(newBtn);

    newBtn.addEventListener('click', function() {
      const accessMenu = document.querySelector('._access-menu');

      if (accessMenu) {
        // Supprime la classe before-collapse si elle existe
        accessMenu.classList.remove('before-collapse');

        // Supprime aussi sur les enfants <ul> si nécessaire
        const innerList = accessMenu.querySelector('ul.before-collapse');
        if (innerList) {
          innerList.classList.remove('before-collapse');
        }

        // Toggle l'ouverture du menu
        accessMenu.classList.toggle('close');
      } else {
        alert('Menu accessibilité non trouvé.');
      }
    });
  }
});
  */
</script>


<script>
// Correction RGAA pour mod_finder (Awesomplete) - Balise <span>
document.addEventListener('DOMContentLoaded', function () {

  function fixAria(node) {
    if (
      node.matches &&
      node.matches('.awesomplete > span.visually-hidden[role="status"]')
    ) {
      node.removeAttribute('role');
      node.setAttribute('aria-live', 'polite');
    }
  }

  // Correction si déjà présent
  document
    .querySelectorAll('.awesomplete > span.visually-hidden[role="status"]')
    .forEach(fixAria);

  // Observer les ajouts dynamiques
  const observer = new MutationObserver(function (mutations) {
    mutations.forEach(function (mutation) {
      mutation.addedNodes.forEach(function (node) {
        if (node.nodeType === 1) {
          fixAria(node);
          node.querySelectorAll &&
            node
              .querySelectorAll(
                '.awesomplete > span.visually-hidden[role="status"]'
              )
              .forEach(fixAria);
        }
      });
    });
  });

  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
});
</script>

<script>
// Correction RGAA pour mod_finder (Awesomplete) - Retours de résultats en français
document.addEventListener('DOMContentLoaded', function () {

  const originalSetter = Object.getOwnPropertyDescriptor(
    Node.prototype,
    'textContent'
  ).set;

  Object.defineProperty(Node.prototype, 'textContent', {
    set: function (value) {

      if (
        this.classList &&
        this.classList.contains('visually-hidden') &&
        this.closest('.awesomplete')
      ) {

        if (value === 'No results found') {
          value = 'Aucun résultat trouvé';
        }

        const match = value && value.match(/^(\d+)\s+results?\s+found$/);
        if (match) {
          value = match[1] + ' résultats trouvés';
        }
      }

      originalSetter.call(this, value);
    }
  });
});
</script>

<script>
// RGAA - Correction du focus sur page de résultats de recherche
window.addEventListener('load', function () {
    if (window.location.hash === '#search-results-focus') {
        const target = document.getElementById('search-results-focus');
        if (target) {
            setTimeout(function () {
                target.focus();
            }, 100);
        }
    }
});
</script>