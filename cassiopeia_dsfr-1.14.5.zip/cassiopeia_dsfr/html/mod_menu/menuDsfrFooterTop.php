<?php
defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Filter\OutputFilter;
use Joomla\CMS\Helper\ModuleHelper;

// Taille Bootstrap (paramètre du module)
$bootstrapSize = (int) $params->get('bootstrap_size', 2);

// Intégration du DSFR
$colClass = 'fr-col-' . ($bootstrapSize > 0 && $bootstrapSize <= 12 ? $bootstrapSize : 2);

?>
<div class="fr-col-12 fr-col-sm-3 <?php echo $colClass ?>">
	<?php if ($module->showtitle) : ?>
		<h3 class="fr-footer__top-cat"><?php echo htmlspecialchars($module->title, ENT_QUOTES, 'UTF-8'); ?></h3>
	<?php endif; ?>
	<ul class="fr-footer__top-list">
	<?php foreach ($list as $item) : ?>
		<li>
			<a href="<?php echo $item->flink; ?>"
			<?php
				$attributes = [];
				if ($item->browserNav == 1) {
					$attributes['target'] = '_blank';
					$attributes['rel'] = 'noopener noreferrer';

					if ($item->anchor_rel == 'nofollow') {
						$attributes['rel'] .= ' nofollow';
					}
				} elseif ($item->browserNav == 2) {
					$options = 'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes,' . $params->get('window_open');
					$attributes['onclick'] = "window.open(this.href, 'targetWindow', '" . $options . "'); return false;";
				}

				foreach ($attributes as $key => $value)
				{
					echo "$key = $value ";
				} ?>> <?php echo $item->title ?>
				<?php if ($attributes['target'] = '_blank')
				{
					echo '<span class="fr-sr-only">nouvelle fenêtre</span>';
				} ?>
			</a>
		</li>
	<?php endforeach; ?>
	</ul>
</div>