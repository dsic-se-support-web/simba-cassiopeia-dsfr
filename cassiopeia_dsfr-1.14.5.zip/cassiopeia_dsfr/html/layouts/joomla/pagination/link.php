<?php
/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   (C) 2014 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

$item    = $displayData['data'];
$display = $item->text;
$app = Factory::getApplication();

// Ajout des classes du DSFR dans les balises lien (a)
switch ((string) $item->text) {
    case Text::_('JLIB_HTML_START'):
        $label = 'Première page';
        $classLink = 'fr-pagination__link fr-pagination__link--first';
        break;

    case Text::_('JPREV'):
        $label = 'Page précédente';
        $classLink = 'fr-pagination__link fr-pagination__link--prev fr-pagination__link--lg-label';
        break;

    case Text::_('JNEXT'):
        $label = 'Page suivante';
        $classLink = 'fr-pagination__link fr-pagination__link--next fr-pagination__link--lg-label';
        break;

    case Text::_('JLIB_HTML_END'):
        $label = 'Dernière page';
        $classLink = 'fr-pagination__link fr-pagination__link--last';
        break;

    default:
        $label = 'Page ' . $item->text;
        $classLink = 'fr-pagination__link';
        break;
}


if ($displayData['active']) {
    if ($item->base > 0) {
        $limit = 'limitstart.value=' . $item->base;
    } else {
        $limit = 'limitstart.value=0';
    }

    $class = 'active';

    if ($app->isClient('administrator')) {
        $link = 'href="#" onclick="document.adminForm.' . $item->prefix . $limit . '; Joomla.submitform();return false;"';
    } elseif ($app->isClient('site')) {
        $link = 'href="' . $item->link . '"';
    }
} else {
    $class = (property_exists($item, 'active') && $item->active) ? 'active' : 'disabled';
}

?>
<?php if ($displayData['active']) : ?>
    <li>
        <a aria-label="<?php echo $label; ?>" <?php echo $link; ?> class="<?php echo $classLink; ?>" title="<?php echo $label; ?>">
            <?php echo $display; ?>
        </a>
    </li>

<?php elseif (isset($item->active) && $item->active) : ?>
    <?php $aria = Text::sprintf('JLIB_HTML_PAGE_CURRENT', strtolower($item->text)); ?>
    <li>
        <a aria-current="page" aria-label="<?php echo $aria; ?>" href="#" class="<?php echo $classLink; ?>" title="<?php echo $label; ?>">
            <?php echo $display; ?>
        </a>
    </li>

<?php else : ?>
    <?php if (in_array($item->text, [Text::_('JLIB_HTML_START'), Text::_('JPREV'), Text::_('JNEXT'), Text::_('JLIB_HTML_END')])) : ?>
        <li>
            <a class="<?php echo $classLink; ?>" aria-disabled="true" role="link" title="<?php echo $label; ?>">
                <?php echo $label; ?>
            </a>
        </li>
    <?php else : ?>
        <li>
            <span class="<?php echo $classLink; ?>" aria-hidden="true" title="<?php echo $label; ?>">
                <?php echo $display; ?>
            </span>
        </li>
    <?php endif; ?>
<?php endif; ?>

