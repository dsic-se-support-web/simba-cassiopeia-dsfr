<?php

/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   (C) 2013 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;

$params  = $displayData->params;

if (is_string($displayData->images)) {
    $images = json_decode($displayData->images);
} else {
    $images = $displayData->images;
}

// Récupérer la classe d'icône dans float_intro si image_intro est vide
$imageIntroClass = '';
if (empty($images->image_intro)) {
    $imageIntroClass = !empty($images->float_intro) ? trim($images->float_intro) : '';
} else {
    $imgclass = empty($images->float_intro) ? $params->get('float_intro') : $images->float_intro;
}

// Cas 1 : Une image d'introduction est définie → comportement standard
if (!empty($images->image_intro)) {
    $layoutAttr = [
        'class' => $this->escape($imgclass),
        'src' => $images->image_intro,
        'alt' => empty($images->image_intro_alt) && empty($images->image_intro_alt_empty) ? false : $images->image_intro_alt,
    ];
    ?>

    <?php if ($params->get('link_intro_image') && ($params->get('access-view') || $params->get('show_noauth', '0') == '1')) : ?>
        <a href="<?php echo Route::_(RouteHelper::getArticleRoute($displayData->slug, $displayData->catid, $displayData->language)); ?>" title="<?php echo $this->escape($displayData->title); ?>">
            <?php echo LayoutHelper::render('joomla.html.image', $layoutAttr); ?>
        </a>
    <?php else : ?>
        <?php echo LayoutHelper::render('joomla.html.image', $layoutAttr); ?>
    <?php endif; ?>

    <?php if (isset($images->image_intro_caption) && $images->image_intro_caption !== '') : ?>
        <figcaption class="caption"><?php echo $this->escape($images->image_intro_caption); ?></figcaption>
    <?php endif; ?>

<?php
// Cas 2 : Pas d’image d'introduction mais classe d’icône définie → afficher icône DSFR
} elseif (!empty($imageIntroClass)) {
    // On s'assure que la classe commence bien par "fr-icon-"
    $iconClass = strpos($imageIntroClass, 'fr-icon-') === 0 ? $imageIntroClass : 'fr-icon-' . $imageIntroClass;
    ?>

    <div class="dsfr-icon-placeholder <?php echo htmlspecialchars($iconClass); ?>" aria-hidden="true"></div>

<?php
}
?>
