<?php

/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   (C) 2017 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

$blockPosition = $displayData['params']->get('info_block_position', 0);

?>
<ul class="fr-tags-group fr-tags-group--sm article-info text-muted" role="listitem">

    <?php
    if (
        $displayData['position'] === 'above' && ($blockPosition == 0 || $blockPosition == 2)
        || $displayData['position'] === 'below' && ($blockPosition == 1)
    ) : ?>

        <?php if ($displayData['params']->get('info_block_show_title', 1)) : ?>
            <li class="article-info-term ">
                <p class="fr-tag">
                    <?php echo Text::_('COM_CONTENT_ARTICLE_INFO'); ?>
                <p class="fr-tag">
            </li>
        <?php endif; ?>



        <?php if ($displayData['params']->get('show_author') && !empty($displayData['item']->author)) : ?>
            <li>
                <?php echo $this->sublayout('author', $displayData); ?>
            </li>
        <?php endif; ?>



        <?php if ($displayData['params']->get('show_parent_category') && !empty($displayData['item']->parent_id)) : ?>
            <li>
                <?php echo $this->sublayout('parent_category', $displayData); ?>
            </li>
        <?php endif; ?>



        <?php if ($displayData['params']->get('show_category')) : ?>
            <li>
                <?php echo $this->sublayout('category', $displayData); ?>
            </li>
        <?php endif; ?>



        <?php if ($displayData['params']->get('show_associations')) : ?>
            <li>
                <?php echo $this->sublayout('associations', $displayData); ?>
            </li>
        <?php endif; ?>



        <?php if ($displayData['params']->get('show_publish_date')) : ?>
            <li>
                <?php echo $this->sublayout('publish_date', $displayData); ?>
            </li>
        <?php endif; ?>



    <?php endif; ?>

    <?php
    if (
        $displayData['position'] === 'above' && ($blockPosition == 0)
        || $displayData['position'] === 'below' && ($blockPosition == 1 || $blockPosition == 2)
    ) : ?>

        <?php if ($displayData['params']->get('show_create_date')) : ?>
            <li>
                <?php echo $this->sublayout('create_date', $displayData); ?>
            </li>
        <?php endif; ?>



        <?php if ($displayData['params']->get('show_modify_date')) : ?>
            <li>
                <?php echo $this->sublayout('modify_date', $displayData); ?>
            </li>
        <?php endif; ?>



        <?php if ($displayData['params']->get('show_hits')) : ?>
            <li>
                <?php echo $this->sublayout('hits', $displayData); ?>
            </li>
        <?php endif; ?>


    <?php endif; ?>
</ul>