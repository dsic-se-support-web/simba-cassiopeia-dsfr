<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_breadcrumbs
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\WebAsset\WebAssetManager;

?>
<!-- aria-expanded="true" du bouton j'ai changer false a true  -->
<nav class="fr-breadcrumb" role="navigation" aria-label="vous êtes ici :">
    <button class="fr-breadcrumb__button" aria-expanded="true" aria-controls="breadcrumb-1">Voir le fil d’Ariane</button>
    <div id="breadcrumb-1">

        <ol class="fr-breadcrumb__list">

            <?php if ($params->get('showHere', 1)) : ?>
                <li class="mod-breadcrumbs__here float-start">
                    <?php echo Text::_('MOD_BREADCRUMBS_HERE'); ?>&#160;
                </li>
            <?php endif; ?>

            <?php
            // Get rid of duplicated entries on trail including home page when using multilanguage
            for ($i = 0; $i < $count; $i++) {
                if ($i === 1 && !empty($list[$i]->link) && !empty($list[$i - 1]->link) && $list[$i]->link === $list[$i - 1]->link) {
                    unset($list[$i]);
                }
            }

            // Find last and penultimate items in breadcrumbs list
            end($list);
            $last_item_key = key($list);
            prev($list);
            $penult_item_key = key($list);

            // Make a link if not the last item in the breadcrumbs
            $show_last = $params->get('showLast', 1);

            $class   = null;

            // Generate the trail
            foreach ($list as $key => $item) :
                if ($key !== $last_item_key) :
                    if (!empty($item->link)) :
                        // $breadcrumbItem = HTMLHelper::_('link', Route::_($item->link), '<span>' . $item->name . '</span>', ['class' => 'pathway']);
                        $breadcrumbItem = '<a class="fr-breadcrumb__link" href="' . $item->link . '">' . $item->name . '</a>';
                    else :
                        $breadcrumbItem = '<a class="fr-breadcrumb__link">' . $item->name . '</a>';
                    endif;
                    echo '<li >' . $breadcrumbItem . '</li>';
                elseif ($show_last) :
                    // Render last item if required.
                    $breadcrumbItem = '<span>' . $item->name . '</span>';
                    $breadcrumbItem = '<a class="fr-breadcrumb__link" aria-current="page">' . $item->name . '</a>';
                    $class          = ' active fr-breadcrumb__link';
                    echo '<li>' . $breadcrumbItem . '</li>';

                endif;
            endforeach; ?>
        </ol>
    </div>
    <?php

    // Structured data as JSON
    $data = [
        '@context'        => 'https://schema.org',
        '@type'           => 'BreadcrumbList',
        '@id'             => Uri::root() . '#/schema/BreadcrumbList/' . (int) $module->id,
        'itemListElement' => []
    ];

    // Use an independent counter for positions. E.g. if Heading items in pathway.
    $itemsCounter = 0;

    // If showHome is disabled use the fallback $homeCrumb for startpage at first position.
    if (isset($homeCrumb)) {
        $data['itemListElement'][] = [
            '@type'    => 'ListItem',
            'position' => ++$itemsCounter,
            'item'     => [
                '@id'  => Route::_($homeCrumb->link, true, Route::TLS_IGNORE, true),
                'name' => $homeCrumb->name,
            ],
        ];
    }

    foreach ($list as $key => $item) {
        // Only add item to JSON if it has a valid link, otherwise skip it.
        if (!empty($item->link)) {
            $data['itemListElement'][] = [
                '@type'    => 'ListItem',
                'position' => ++$itemsCounter,
                'item'     => [
                    '@id'  => Route::_($item->link, true, Route::TLS_IGNORE, true),
                    'name' => $item->name,
                ],
            ];
        } elseif ($key === $last_item_key) {
            // Add the last item (current page) to JSON, but without a link.
            // Google accepts items without a URL only as the current page.
            $data['itemListElement'][] = [
                '@type'    => 'ListItem',
                'position' => ++$itemsCounter,
                'item'     => [
                    'name' => $item->name,
                ],
            ];
        }
    }

    if ($itemsCounter) {
        /** @var WebAssetManager $wa */
        $wa = $app->getDocument()->getWebAssetManager();
        $prettyPrint = JDEBUG ? JSON_PRETTY_PRINT : 0;
        $wa->addInline(
            'script',
            json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | $prettyPrint),
            ['name' => 'inline.breadcrumbs-schemaorg'],
            ['type' => 'application/ld+json']
        );
    }
    ?>
</nav>