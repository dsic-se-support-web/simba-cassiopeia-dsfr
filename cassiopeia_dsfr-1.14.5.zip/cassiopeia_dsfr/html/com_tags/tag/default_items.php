<?php

/**
 * @package     Joomla.Site
 * @subpackage  com_tags
 *
 * @copyright   (C) 2013 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Component\Tags\Site\Helper\RouteHelper;

/** @var \Joomla\Component\Tags\Site\View\Tag\HtmlView $this */
/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('com_tags.tag-default');

// Get the user object.
$user = $this->getCurrentUser();

// Check if user is allowed to add/edit based on tags permissions.
// Do we really have to make it so people can see unpublished tags???
$canEdit      = $user->authorise('core.edit', 'com_tags');
$canCreate    = $user->authorise('core.create', 'com_tags');
$canEditState = $user->authorise('core.edit.state', 'com_tags');
?>
<div class="com-tags__items">
    <form action="<?php echo htmlspecialchars(Uri::getInstance()->toString()); ?>" method="post" name="adminForm" id="adminForm">
        <?php if ($this->params->get('filter_field') || $this->params->get('show_pagination_limit')) : ?>
            <?php if ($this->params->get('filter_field')) : ?>
                <div class="com-tags-tags__filter btn-group">
                  <div style="display: ruby;">
                    <div class="fr-select-group">
                    <label class="filter-search-lbl visually-hidden" for="filter-search">
                        <?php echo Text::_('COM_TAGS_TITLE_FILTER_LABEL'); ?>
                    </label>
                    <input
                        type="text"
                        name="filter-search"
                        id="filter-search"
                        value="<?php echo $this->escape($this->state->get('list.filter')); ?>"
                        class="fr-input" onchange="document.adminForm.submit();"
                        placeholder="<?php echo Text::_('COM_TAGS_TITLE_FILTER_LABEL'); ?>"
                    >
                    </div>
                    <button type="submit" name="filter_submit" class="fr-btn fr-btn--tertiary"><?php echo Text::_('JGLOBAL_FILTER_BUTTON'); ?></button>
                    <button type="reset" name="filter-clear-button" class="fr-btn fr-btn--tertiary"><?php echo Text::_('JSEARCH_FILTER_CLEAR'); ?></button>
                  </div>
                </div>
            <?php endif; ?>
            <?php if ($this->params->get('show_pagination_limit')) : ?>
                <div class="fr-select-group float-end">
                    <label for="limit" class="visually-hidden fr-label">
                        <?php echo Text::_('JGLOBAL_DISPLAY_NUM'); ?>
                    </label>
                    <?php echo $this->pagination->getLimitBox(); ?>
                </div>
            <?php endif; ?>

            <input class="fr-input" type="hidden" name="limitstart" value="">
            <input class="fr-input" type="hidden" name="task" value="">
        <?php endif; ?>
    </form>

    <?php if (empty($this->items)) : ?>
        <div class="fr-alert fr-alert--info">
            <span class="icon-info-circle" aria-hidden="true"></span><span class="visually-hidden"><?php echo Text::_('INFO'); ?></span>
            <?php echo Text::_('COM_TAGS_NO_ITEMS'); ?>
        </div>
    <?php else : ?>
		<div class="fr-grid-row fr-grid-row--gutters">
			<?php foreach ($this->items as $i => $item) : ?>
			<?php
				$images = json_decode($item->core_images);
				$itemLink = Route::_(RouteHelper::getItemRoute(
                $item->content_item_id,
                $item->core_alias,
                $item->core_catid,
                $item->core_language,
                $item->type_alias,
                $item->router
				));

				$hasImage = !empty($images->image_intro);
				$imageAlt = !empty($images->image_intro_alt) ? $images->image_intro_alt : '';
				$title = $this->escape($item->core_title);
				$excerpt = strip_tags($item->core_body);
				$excerpt = HTMLHelper::_('string.truncate', $excerpt, $this->params->get('tag_list_item_maximum_characters', 200));
			?>
			<div class="fr-col-12">
				<div class="fr-card fr-enlarge-link fr-card--sm fr-card--horizontal" role="article" aria-labelledby="card-title-<?php echo $i; ?>">
                <?php if ($hasImage) : ?>
                    <div class="fr-card__header">
                        <div class="fr-card__img">
                            <img class="fr-responsive-img"
                                src="<?php echo htmlspecialchars($images->image_intro, ENT_QUOTES, 'UTF-8'); ?>"
                                alt="<?php echo htmlspecialchars($imageAlt, ENT_QUOTES, 'UTF-8'); ?>">
                        </div>
                    </div>
                <?php endif; ?>

					<div class="fr-card__body">
						<div class="fr-card__content">
							<h3 id="card-title-<?php echo $i; ?>" class="fr-card__title">
								<a href="<?php echo $itemLink; ?>">
									<?php echo $title; ?>
								</a>
							</h3>

							<?php echo $item->event->afterDisplayTitle; ?>

							<p class="fr-card__desc"><?php echo $excerpt; ?></p>

							<div class="fr-card__start">
								<!-- Espace disponible pour ajouter les tags -->
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
    <?php endif; ?>
</div>
