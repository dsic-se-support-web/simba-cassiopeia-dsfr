<?php
defined('_JEXEC') or die;

use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Factory;

// Paramètres d'affichage
$layoutMode  = (int) $params->get('articles_layout');
$columns     = max(1, (int) $params->get('layout_columns', 3));

$gridClass   = $layoutMode ? 'fr-grid-row' : '';
$columnClass = $layoutMode ? 'fr-col-12 fr-col-lg-' . (12 / $columns) : 'fr-col-12';

// Paramètres date
$showDate  = (bool) $params->get('show_date');
$dateField = $params->get('show_date_field', 'created');

// Paramètre template pour afficher l'icône calendrier
$app      = Factory::getApplication();
$template = $app->getTemplate(true);
$templateParams = $template->params;
$showIcon = (int) $templateParams->get('showCalenderIcon', 1);
?>

<div class="mod-articles-items <?php echo $gridClass; ?>">
	<?php foreach ($items as $item) :
		$hasImage = in_array($params->get('img_intro_full'), ['intro','full']) && !empty($item->imageSrc);
		$link     = htmlspecialchars($item->link, ENT_QUOTES, 'UTF-8');

		$dateClass = '';
		$label     = '';
		$date      = null;

		if ($showDate) {

			$dateMap = [
				'publish_up' => ['published', 'Publié le : ', $item->publish_up],
				'modified'   => ['modified',  'Mis à jour le : ', $item->modified],
				'created'    => ['create',    'Créé le : ', $item->created],
			];

			if (isset($dateMap[$dateField])) {
				[$dateClass, $label, $date] = $dateMap[$dateField];
			}
		}
	?>

	<div class="blog-item fr-col <?php echo $columnClass; ?>">
		<div class="fr-card fr-enlarge-link">
			<div class="fr-card__body">
				<div class="item-content fr-card__content">
					<?php if ($params->get('item_title')) : ?>
						<div class="item-title fr-card__title">
								<?php if ($params->get('link_titles')) : ?>
									<a href="<?php echo $link; ?>" class="mod-articles-link <?php echo $item->active; ?>" itemprop="url">
										<?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>
									</a>
								<?php else : ?>
									<?php echo htmlspecialchars($item->title, ENT_QUOTES, 'UTF-8'); ?>
								<?php endif; ?>
						</div>
					<?php endif; ?>

					<?php echo $item->event->afterDisplayTitle; ?>

					<?php if ($showDate && $date) : ?>
                        <ul class="fr-tags-group fr-tags-group--sm article-info text-muted" role="list">
                            <li>
                                <p class="<?php echo $dateClass; ?> fr-tag">
                                    <?php if ($showIcon) : ?>
                                        <span class="fr-icon-calendar-line fr-icon--sm" aria-hidden="true"></span>
                                    <?php endif; ?>
                                    <time datetime="<?php echo HTMLHelper::_('date', $date, 'c'); ?>">
                                        <?php echo $label . HTMLHelper::_('date', $date, 'd/m/Y'); ?>
                                    </time>
                                </p>
                            </li>
                        </ul>
					<?php endif; ?>

					<div class="fr-card__desc">
					
						<?php echo $item->event->beforeDisplayContent; ?>
						
						<?php if ($params->get('show_introtext', 1)) : ?>
							<?php echo $item->introtext; ?>
						<?php endif; ?>
						
						<?php echo $item->event->afterDisplayContent; ?>
					</div>

					<?php if ($params->get('show_readmore')) : ?>
						<p class="fr-card__footer">
							<?php
							echo LayoutHelper::render(
								'joomla.content.readmore',
								[
									'item'   => $item,
									'params' => $item->params,
									'link'   => $item->link
								]
							);
							?>
						</p>
					<?php endif; ?>

				</div>
			</div>

			<?php if ($hasImage) : ?>
				<div class="fr-card__header">
					<div class="fr-card__img">
						<div class="card-image-wrapper">
							<?php
							echo LayoutHelper::render(
								'joomla.content.' . $params->get('img_intro_full') . '_image',
								$item
							);
							?>
						</div>
					</div>

					<?php if ($params->get('show_tags', 0) && !empty($item->tags->itemTags)) : ?>
						<?php echo LayoutHelper::render('joomla.content.tags', $item->tags->itemTags); ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>

		</div>
	</div>

<?php endforeach; ?>

</div>