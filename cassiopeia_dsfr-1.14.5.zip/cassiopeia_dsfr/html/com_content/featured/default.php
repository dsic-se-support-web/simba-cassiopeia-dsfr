<?php

/**
 * @package     Joomla.Site
 * @subpackage  com_content
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

?>
<!-- Ci dessous le code du module qui affiche les articles épinglé -->
<div class="blog-featured fr-container--fluid">

    <!-- <?php if ($this->params->get('show_page_heading') != 0) : ?>
        <div class="page-header">
            <h1>
                <?php echo $this->escape($this->params->get('page_heading')); ?>
            </h1>
        </div>
    <?php endif; ?> -->

    <?php if (!empty($this->lead_items)) : ?>
        <div class="blog-items items-leading  <?php echo $this->params->get('blog_class_leading'); ?>">
            <?php foreach ($this->lead_items as &$item) : ?>
                <div class="blog-item fr-col-12 fr-card fr-enlarge-link fr-card--horizontal fr-card--horizontal-half">
                    <?php
                    $this->item = &$item;
                    echo $this->loadTemplate('item_fullwidth');
                    ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>


    <?php if (!empty($this->intro_items)) : ?>
        <?php $blogClass = $this->params->get('blog_class', ''); ?>
        <?php if ((int) $this->params->get('num_columns') > 1) : ?>
            <?php $blogClass .= (int) $this->params->get('multi_column_order', 0) === 0 ? ' masonry-' : ' columns-'; ?>
            <?php $blogClass .= (int) $this->params->get('num_columns'); ?>
        <?php endif; ?>

        <!-- les card se trouve a l'interieur -->
        <div class="<?php echo $blogClass; ?>  fr-grid-row fr-col-12 fr-mb-3w fr-mt-1v <?php if (!empty($this->lead_items)) : echo "card_accueil";
                                                                                endif ?> ">

            <?php foreach ($this->intro_items as $key => &$item) : ?>
                <?php // calcul pour l'affichage de la dimension des cards
                $classToDisplay = "";
                // $nbItemAfficher = count($this->intro_items);
                $nbColonne = $this->params->get('num_columns');
                $nbColonne >= 4 ? $classToDisplay = "fr-col-lg-3" : ($nbColonne === 3 ? $classToDisplay = "fr-col-lg-4" : ($nbColonne === 2 ? $classToDisplay = "fr-col-lg-6" : ($nbColonne === 1 ? $classToDisplay = "fr-col-lg-12" : "")));
                ?>

                <div class="blog-item fr-col fr-col-12 <?php echo $classToDisplay ?> ">
                    <div class="fr-card fr-enlarge-link ">

                        <?php
                        $this->item = &$item;
                        echo $this->loadTemplate('item');
                        ?>

                    </div>
                </div>

            <?php endforeach; ?>
        </div>
        <!-- fin -->
    <?php endif; ?>


    <?php if (!empty($this->link_items)) : ?>
        <div class="items-more">
            <?php echo $this->loadTemplate('links'); ?>
        </div>
    <?php endif; ?>

    <?php if ($this->params->def('show_pagination', 2) == 1  || ($this->params->get('show_pagination') == 2 && $this->pagination->pagesTotal > 1)) : ?>
        <div class="w-100">
            <?php if ($this->params->def('show_pagination_results', 1)) : ?>
                <p class="counter float-end pt-3 pe-2">
                    <?php echo $this->pagination->getPagesCounter(); ?>
                </p>
            <?php endif; ?>
            <?php echo $this->pagination->getPagesLinks(); ?>
        </div>
    <?php endif; ?>

</div>