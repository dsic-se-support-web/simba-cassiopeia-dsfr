<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Content\Site\Helper\RouteHelper;
use Joomla\CMS\Helper\TagsHelper;
use Joomla\Registry\Registry;

/** @var \Joomla\Component\Content\Site\View\Category\HtmlView $this */

$user   = $this->getCurrentUser();
$groups = $user->getAuthorisedViewLevels();

if ($this->maxLevel != 0 && count($this->children[$this->category->id]) > 0) : ?>

	<div class="fr-grid-row fr-grid-row--gutters">

		<?php foreach ($this->children[$this->category->id] as $id => $child) :  ?>

			<?php if (in_array($child->access, $groups)) : ?>
				<?php if ($this->params->get('show_empty_categories') || $child->getNumItems(true) || count($child->getChildren())) : ?>

					<?php
					/* récupération image catégorie */
					$catParams = new Joomla\Registry\Registry($child->params);
					$catImage = $catParams->get('image');

					/* récupération tags de la catégorie */
					$tagsHelper = new \Joomla\CMS\Helper\TagsHelper;
					$tags = $tagsHelper->getItemTags('com_content.category', $child->id);
					?>

		<div class="fr-col-12 fr-col-md-6 fr-col-lg-4">
			<article class="fr-card fr-enlarge-link">
				<?php if (!empty($catImage)) : ?>
					<div class="fr-card__header">
						<div class="fr-card__img">
							<img src="<?php echo htmlspecialchars($catImage); ?>" class="fr-responsive-img"	alt="<?php echo $this->escape($child->title); ?>">
						</div>
					</div>
				<?php endif; ?>
			<div class="fr-card__body">
				<div class="fr-card__content">
					<h3 class="fr-card__title">
						<a href="<?php echo Route::_(RouteHelper::getCategoryRoute($child->id, $child->language)); ?>">
							<?php echo $this->escape($child->title); ?>
						</a>
					</h3>
				<?php if ($this->params->get('show_cat_num_articles', 1)) : ?>
					<p class="fr-card__detail">
						<?php echo $child->getNumItems(true); ?> article(s)
					</p>
				<?php endif; ?>

				<?php if ($this->params->get('show_subcat_desc') == 1 && !empty($child->description)) : ?>
					<p class="fr-card__desc">
						<?php echo HTMLHelper::_('content.prepare', $child->description, '', 'com_content.category'); ?>
					</p>
				<?php endif; ?>

				<?php if (!empty($tags)) : ?>
					<ul class="fr-tags-group">
						<?php foreach ($tags as $tag) : ?>
							<li>
								<a class="fr-tag" href="<?php echo Route::_('index.php?option=com_tags&view=tag&id=' . $tag->tag_id); ?>">
									<?php echo htmlspecialchars($tag->title); ?>
								</a>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				</div>
			</div>
			</article>
		</div>
				<?php endif; ?>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>

<?php endif; ?>