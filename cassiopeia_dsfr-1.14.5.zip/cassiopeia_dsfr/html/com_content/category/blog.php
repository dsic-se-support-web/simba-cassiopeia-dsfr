<?php
/**
 * @package     Joomla.Site
 * @subpackage  com_content
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Layout\LayoutHelper;

$app = Factory::getApplication();

// Préparation des contenus de catégorie
$this->category->text = $this->category->description;
$app->triggerEvent('onContentPrepare', [$this->category->extension . '.categories', &$this->category, &$this->params, 0]);
$this->category->description = $this->category->text;

$results = $app->triggerEvent('onContentAfterTitle', [$this->category->extension . '.categories', &$this->category, &$this->params, 0]);
$afterDisplayTitle = trim(implode("\n", $results));

$results = $app->triggerEvent('onContentBeforeDisplay', [$this->category->extension . '.categories', &$this->category, &$this->params, 0]);
$beforeDisplayContent = trim(implode("\n", $results));

$results = $app->triggerEvent('onContentAfterDisplay', [$this->category->extension . '.categories', &$this->category, &$this->params, 0]);
$afterDisplayContent = trim(implode("\n", $results));

$htag = $this->params->get('show_page_heading') ? 'h2' : 'h1';
?>

<div class="com-content-category-blog blog fr-container--fluid">

    <?php if ($this->params->get('show_page_heading')) : ?>
        <div class="page-header">
            <h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
        </div>
    <?php endif; ?>

    <?php if ($this->params->get('show_category_title', 1)) : ?>
        <<?php echo $htag; ?>>
            <?php echo $this->category->title; ?>
        </<?php echo $htag; ?>>
    <?php endif; ?>

    <?php echo $afterDisplayTitle; ?>

    <?php if ($this->params->get('show_cat_tags', 1) && !empty($this->category->tags->itemTags)) : ?>
        <?php $this->category->tagLayout = new FileLayout('joomla.content.tags'); ?>
        <?php echo $this->category->tagLayout->render($this->category->tags->itemTags); ?>
    <?php endif; ?>

    <?php if ($beforeDisplayContent || $afterDisplayContent || $this->params->get('show_description', 1) || $this->params->def('show_description_image', 1)) : ?>
        <div class="category-desc fr-mb-3w">
            <?php if ($this->params->get('show_description_image') && $this->category->getParams()->get('image')) : ?>
                <?php echo LayoutHelper::render('joomla.html.image', [
                    'src' => $this->category->getParams()->get('image'),
                    'alt' => $this->category->getParams()->get('image_alt'),
                ]); ?>
            <?php endif; ?>
            <?php echo $beforeDisplayContent; ?>
            <?php if ($this->params->get('show_description') && $this->category->description) : ?>
                <?php echo HTMLHelper::_('content.prepare', $this->category->description, '', 'com_content.category'); ?>
            <?php endif; ?>
            <?php echo $afterDisplayContent; ?>
        </div>
    <?php endif; ?>

    <?php /* --- AFFICHAGE DES ARTICLES --- */ ?>
    
    <?php if (empty($this->lead_items) && empty($this->link_items) && empty($this->intro_items)) : ?>
        <?php if ($this->params->get('show_no_articles', 1)) : ?>
            <div class="fr-alert fr-alert--info fr-mb-3w">
                <p><?php echo Text::_('COM_CONTENT_NO_ARTICLES'); ?></p>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (!empty($this->lead_items)) : ?>
        <div class="items-leading fr-grid-row fr-grid-row--gutters fr-mb-3w">
            <?php foreach ($this->lead_items as &$item) : ?>
                <div class="fr-col-12">
                    <div class="fr-card fr-enlarge-link fr-card--horizontal">
                        <?php $this->item = &$item; echo $this->loadTemplate('item'); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($this->intro_items)) : ?>
        <div class="fr-grid-row fr-grid-row--gutters fr-mb-3w">
            <?php foreach ($this->intro_items as $key => &$item) : ?>
                <?php 
                $nbColonne = (int) $this->params->get('num_columns', 3);
                $gridClass = "fr-col-12 " . ($nbColonne >= 4 ? "fr-col-md-3" : ($nbColonne === 3 ? "fr-col-md-4" : "fr-col-md-6"));
                ?>
                <div class="<?php echo $gridClass; ?>">
                    <div class="fr-card fr-enlarge-link">
                        <?php $this->item = &$item; echo $this->loadTemplate('item'); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php /* --- AFFICHAGE DES SOUS-CATÉGORIES --- */ ?>
    
	<?php if ($this->maxLevel != 0 && !empty($this->children[$this->category->id])) : ?>
		<div class="com-content-category-blog__children fr-mt-6w">

			<?php if ($this->params->get('show_category_heading_title_text', 1)) : ?>
				<h3 class="fr-h4"><?php echo Text::_('JGLOBAL_SUBCATEGORIES'); ?></h3>
			<?php endif; ?>

			<?php echo $this->loadTemplate('children'); ?>

		</div>
	<?php endif; ?>

    <?php /* --- PAGINATION --- */ ?>
    
    <?php if (($this->params->def('show_pagination', 1) == 1 || ($this->params->get('show_pagination') == 2)) && ($this->pagination->pagesTotal > 1)) : ?>
        <nav role="navigation" class="fr-pagination" aria-label="Pagination">
            <?php echo $this->pagination->getPagesLinks(); ?>
        </nav>
    <?php endif; ?>
</div>