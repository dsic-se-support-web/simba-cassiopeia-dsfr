<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_tags_popular
 *
 * @copyright   (C) 2013 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\Component\Tags\Site\Helper\RouteHelper;
use Joomla\Registry\Registry;
?>
<div class="mod-tagspopular tagspopular">
<?php if (!count($list)) : ?>
    <div class="alert alert-info">
        <span class="icon-info-circle" aria-hidden="true"></span><span class="visually-hidden"><?php echo Text::_('INFO'); ?></span>
        <?php echo Text::_('MOD_TAGS_POPULAR_NO_ITEMS_FOUND'); ?>
    </div>
<?php else : ?>
    <ul class="fr-badges-group">
    <?php foreach ($list as $item) : ?>

		<!-- Début - Récupération des informations de couleurs personnalisées des tags -->
			<?php $tagParams = new Registry($item->params); ?>
			<?php $link_class = $tagParams->get('tag_link_class', 'btn-info'); ?>
		<!-- Fin - Récupération des informations de couleurs personnalisées des tags -->

    <li>
        <div class="fr-badge <?php echo $link_class; ?>">
           <a href="<?php echo Route::_(RouteHelper::getComponentTagRoute($item->tag_id . ':' . $item->alias, $item->language)); ?>">
            <?php echo htmlspecialchars($item->title, ENT_COMPAT, 'UTF-8'); ?> </a>
        <?php if ($display_count) : ?>
            <span class="tag-count fr-badge bg-info"><?php echo $item->count; ?></span>
        <?php endif; ?>
        </div>
    </li>
    <?php endforeach; ?>
    </ul>
<?php endif; ?>
</div>
