<?php

/**
 * @package     Joomla.Site
 * @subpackage  Layout
 *
 * @copyright   (C) 2013 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Factory;

$app      = Factory::getApplication();
$template = $app->getTemplate(true);
$params   = $template->params;

$showIcon = (int) $params->get('showCalenderIcon', 1);
?>
<p class="published fr-tag">
    <?php if ($showIcon) : ?>
        <span class="fr-icon-calendar-line fr-icon--sm" aria-hidden="true"></span>
    <?php endif; ?>
    <time datetime="<?php echo HTMLHelper::_('date', $displayData['item']->publish_up, 'c'); ?>">
    <?php //echo Text::sprintf('COM_CONTENT_PUBLISHED_DATE_ON', HTMLHelper::_('date', $displayData['item']->publish_up, Text::_('DATE_FORMAT_LC3'))); 
        ?>
    <?php echo Text::sprintf('COM_CONTENT_PUBLISHED_DATE_ON', HTMLHelper::_('date', $displayData['item']->publish_up, 'd/m/Y')); ?>
    </time>
</p>
