<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_finder
 *
 * @copyright   (C) 2011 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;


// Load the smart search component language file.
$lang = $app->getLanguage();
$lang->load('com_finder', JPATH_SITE);


$showLabel  = $params->get('show_label', 1);
$labelClass = (!$showLabel ? 'visually-hidden ' : '') . 'finder ';

$input = '<input type="text" name="q" id="search" class="js-finder-search-query form-control fr-input" value="' . htmlspecialchars($app->input->get('q', '', 'string'), ENT_COMPAT, 'UTF-8') . '"'
	. ' placeholder="' . Text::_('MOD_FINDER_SEARCH_VALUE') . '">';

$label      = '<label for="search-' . $module->id . '-input"  class="fr-label  ' . $labelClass . '"> Rechercher </label>';


$output = '';

$output .= '<div class="fr-search-bar" >';
$output .= $label;
$output .= $input;
$output .= '<button class="fr-btn" type="submit" title="Rechercher">Rechercher</button>';



Text::script('MOD_FINDER_SEARCH_VALUE', true);

/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('com_finder');

/*
 * This segment of code sets up the autocompleter.
 */
if ($params->get('show_autosuggest', 1)) {
	$wa->usePreset('awesomplete');
	$app->getDocument()->addScriptOptions('finder-search', array('url' => Route::_('index.php?option=com_finder&task=suggestions.suggest&format=json&tmpl=component')));
}

$wa->useScript('com_finder.finder');

$finderHelper = $app->bootModule('mod_finder', 'site')->getHelper('FinderHelper');

?>

<form class="mod-finder js-finder-searchform form-search" action="<?php echo Route::_($route); ?>" method="GET" role="search">
	<?php echo $output; ?>
</form>